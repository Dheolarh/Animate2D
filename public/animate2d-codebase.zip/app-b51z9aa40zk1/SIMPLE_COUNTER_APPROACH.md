# Simple Counter-Based Selection System

## The Concept

Instead of complex timing logic, use a simple counter to track selection state:

- **Count = 0**: Nothing selected → can create new objects
- **Count = 1**: Something selected → clicking empty space ONLY deselects

## The Rule

**"It cannot create a new object if count is 1"**

This simple rule prevents the bug where clicking to deselect would create a new object.

## Implementation

### 1. The Counter

```typescript
// Simple counter: 0 = nothing selected, 1 = something selected
const selectionCountRef = useRef<number>(0);
```

### 2. Update Counter on Selection Events

```typescript
// When user selects an object
canvas.on('selection:created', () => {
  console.log('[SELECTION] Count: 0 → 1 (object selected)');
  selectionCountRef.current = 1;
});

// When user switches selection
canvas.on('selection:updated', () => {
  console.log('[SELECTION] Count: 1 (selection updated)');
  selectionCountRef.current = 1;
});

// When user deselects
canvas.on('selection:cleared', () => {
  console.log('[SELECTION] Count: 1 → 0 (deselected)');
  selectionCountRef.current = 0;
});
```

### 3. Check Counter in Mouse Down

```typescript
const handleMouseDown = (e: fabric.IEvent) => {
  if (canvas.isDrawingMode) return;
  
  const pointer = canvas.getPointer(e.e);
  const target = canvas.findTarget(e.e as any, false);
  
  console.log('[MOUSE DOWN] Count:', selectionCountRef.current, 'Target:', !!target);
  
  // Case 1: Clicking on an object → let Fabric.js handle it
  if (target) {
    return;
  }
  
  // Case 2: Count = 1 → ONLY deselect, do NOT create
  if (selectionCountRef.current === 1) {
    console.log('[MOUSE DOWN] Count is 1, deselecting only');
    canvas.discardActiveObject();
    selectionCountRef.current = 0;
    canvas.renderAll();
    return; // ← STOP HERE
  }
  
  // Case 3: Count = 0 → can create new object
  console.log('[MOUSE DOWN] Count is 0, can create object');
  
  if (drawingState.tool === 'text') {
    addText(pointer.x, pointer.y);
    return;
  }
  
  // For shapes/lines, wait for drag in mouse:move
};
```

### 4. Update Counter When Programmatically Selecting

```typescript
// When creating text
canvas.add(text);
canvas.setActiveObject(text);
selectionCountRef.current = 1; // Set count to 1
console.log('[SELECTION] Count: 0 → 1 (text created and selected)');

// When creating shape
canvas.setActiveObject(shape);
selectionCountRef.current = 1; // Set count to 1
console.log('[SELECTION] Count: 0 → 1 (shape created and selected)');

// When creating line
canvas.setActiveObject(line);
selectionCountRef.current = 1; // Set count to 1
console.log('[SELECTION] Count: 0 → 1 (line created and selected)');

// When adding image
canvas.setActiveObject(img);
selectionCountRef.current = 1; // Set count to 1
console.log('[SELECTION] Count: 0 → 1 (image added and selected)');
```

### 5. Check Counter in Mouse Move (for drag-to-create)

```typescript
const handleMouseMove = (e: fabric.IEvent) => {
  // Only start drawing if count = 0
  if (mouseDownPositionRef.current && 
      !lineDrawingRef.current.isDrawing && 
      !shapeDrawingRef.current.isDrawing && 
      selectionCountRef.current === 0) {
    
    const isDragging = /* calculate distance */;
    
    if (isDragging) {
      // Start creating shape/line
    }
  }
  
  // Continue updating during drag...
};
```

## How It Works

### Scenario 1: Creating Text
1. Count = 0 (nothing selected)
2. Click empty space → creates text
3. Text is selected → count = 1
4. Click empty space → count is 1, so ONLY deselect (count = 0)
5. Click empty space again → count is 0, so create new text

### Scenario 2: Creating Shape
1. Count = 0 (nothing selected)
2. Click and drag → creates shape
3. Shape is selected → count = 1
4. Click empty space → count is 1, so ONLY deselect (count = 0)
5. Click and drag again → count is 0, so create new shape

### Scenario 3: Clicking on Objects
1. Count = 0
2. Click on object A → Fabric.js selects it, count = 1
3. Click on object B → Fabric.js switches selection, count = 1
4. Click empty space → count is 1, so deselect (count = 0)

## The Three Cases

| Case | Condition | Action |
|------|-----------|--------|
| 1 | Clicking on object | Let Fabric.js handle (return early) |
| 2 | Count = 1 (selected) | Deselect only, set count = 0, return |
| 3 | Count = 0 (not selected) | Create new object, set count = 1 |

## Why This Works

1. **Simple Logic**: Just check if count is 0 or 1
2. **No Timing Issues**: We're not trying to capture state before Fabric.js processes
3. **Clear Rule**: "Cannot create if count is 1"
4. **Easy to Debug**: Console logs show count changes clearly

## Console Output Example

```
[SELECTION] Count: 0 → 1 (text created and selected)
[MOUSE DOWN] Count: 1, Target: false
[MOUSE DOWN] Count is 1, deselecting only
[SELECTION] Count: 1 → 0 (deselected)
[MOUSE DOWN] Count: 0, Target: false
[MOUSE DOWN] Count is 0, can create object, tool: text
[SELECTION] Count: 0 → 1 (text created and selected)
```

## Testing Checklist

- [x] Create text → count shows 1
- [x] Click empty space → count shows 0, no new text created
- [x] Click empty space again → count is 0, new text created
- [x] Create shape → count shows 1
- [x] Click empty space → count shows 0, no new shape created
- [x] Click on object → count shows 1
- [x] Click empty space → count shows 0

## Comparison with Previous Approach

| Aspect | Previous (Timing-based) | New (Counter-based) |
|--------|------------------------|---------------------|
| Complexity | High (capture state early, drag detection) | Low (simple counter) |
| Logic | Check `hadActiveSelection` before Fabric.js | Check `count === 1` |
| Debugging | Hard (timing issues) | Easy (count is always visible) |
| Understanding | Complex (timing, events) | Simple (count rule) |
| Maintenance | Difficult | Easy |

## Key Insight

The user's insight: **"it can not do a select if count is on 1"**

This simple rule eliminates all the complexity:
- No need to capture state before Fabric.js processes
- No need to worry about timing
- Just check: is count 1? Then only deselect, don't create.

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Replaced `hasActiveSelectionRef` with `selectionCountRef`
  - Updated selection event listeners to set count
  - Updated mouse:down to check count
  - Updated mouse:move to check count
  - Updated all programmatic selections to set count

## Version

- Implemented in: v114
- Replaces: v113 (Claude's timing-based fix)
- Concept: User's simple counter approach
