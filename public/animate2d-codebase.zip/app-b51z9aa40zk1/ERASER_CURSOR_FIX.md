# Eraser Cursor Icon Fix - Replace Crosshair with Circle

## Problem Description

**Symptom:** When using the eraser tool, the cursor shows a "+" (crosshair) icon instead of a normal thin circle that represents the brush size, similar to how Canva displays the eraser cursor.

**User Experience Issue:** The crosshair cursor doesn't provide visual feedback about the eraser size, making it difficult for users to know the area that will be erased.

## Root Cause

Fabric.js uses a crosshair cursor by default when `isDrawingMode = true`. This is the standard cursor for drawing tools, but it's not ideal for the eraser tool where users expect to see a circle representing the eraser size.

## The Solution

### Approach: Custom CSS Cursor with SVG

Instead of using Fabric.js's built-in cursor options, we created custom CSS cursors using inline SVG data URIs. This allows us to:

1. Show a thin circle cursor for both brush and eraser tools
2. Maintain consistent visual feedback across tools
3. Avoid the crosshair cursor that doesn't represent brush/eraser size

### Implementation

#### Step 1: Add Custom Cursor CSS Classes

Added to `src/index.css`:

```css
@layer utilities {
  /* Custom cursor for eraser tool - thin circle */
  .cursor-eraser {
    cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" fill="none" stroke="black" stroke-width="1.5" opacity="0.6"/></svg>') 12 12, crosshair;
  }
  
  /* Custom cursor for brush tool - thin circle */
  .cursor-brush {
    cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" fill="none" stroke="black" stroke-width="1.5" opacity="0.6"/></svg>') 12 12, crosshair;
  }
}
```

**SVG Breakdown:**
- `width="24" height="24"` - Cursor size
- `viewBox="0 0 24 24"` - Coordinate system
- `<circle cx="12" cy="12" r="8">` - Circle centered at (12, 12) with radius 8
- `fill="none"` - Hollow circle (not filled)
- `stroke="black"` - Black outline
- `stroke-width="1.5"` - Thin stroke (1.5px)
- `opacity="0.6"` - Semi-transparent (60%)
- `12 12` in cursor URL - Hotspot position (center of cursor)
- `crosshair` - Fallback cursor if SVG fails to load

#### Step 2: Apply CSS Classes Dynamically

Updated `FabricDrawingCanvas.tsx`:

```typescript
<canvas 
  ref={canvasRef} 
  className={cn(
    "border border-border shadow-lg",
    drawingState.tool === 'eraser' && 'cursor-eraser',
    drawingState.tool === 'brush' && 'cursor-brush'
  )}
  style={{ zIndex: 2 }}
/>
```

**How It Works:**
- Uses `cn()` utility to conditionally apply classes
- When tool is 'eraser', applies `cursor-eraser` class
- When tool is 'brush', applies `cursor-brush` class
- When tool is something else, no custom cursor class is applied

## Why This Approach?

### Alternative 1: Fabric.js `freeDrawingCursor` Property
```typescript
canvas.freeDrawingCursor = 'default'; // or 'crosshair', 'pointer', etc.
```
**Rejected:** Limited to standard CSS cursor values, can't create custom circle cursor

### Alternative 2: Dynamic SVG Cursor Based on Brush Size
```typescript
const cursorSize = brushSize * 2;
canvas.freeDrawingCursor = `url('data:image/svg+xml;utf8,<svg>...</svg>') ${cursorSize/2} ${cursorSize/2}, crosshair`;
```
**Rejected:** More complex, requires updating cursor on every brush size change, potential performance impact

### Alternative 3: CSS Classes with Fixed Size (CHOSEN)
```css
.cursor-eraser { cursor: url('...svg...') 12 12, crosshair; }
```
**Chosen:** Simple, performant, consistent visual feedback, easy to maintain

## Cursor Design Specifications

### Visual Properties
- **Shape:** Circle
- **Size:** 24x24 pixels (visible area ~16px diameter)
- **Stroke:** 1.5px black
- **Fill:** None (hollow)
- **Opacity:** 60% (semi-transparent)
- **Hotspot:** Center (12, 12)

### Why These Values?

1. **24x24 Size:** Standard cursor size, not too large or small
2. **Radius 8:** Provides good visibility without being obtrusive
3. **Stroke 1.5px:** Thin enough to be precise, thick enough to be visible
4. **Black Color:** High contrast on most backgrounds
5. **60% Opacity:** Visible but doesn't obscure canvas content
6. **Hollow Circle:** Shows what's underneath, better for precision
7. **Center Hotspot:** Cursor center aligns with actual drawing point

## Browser Compatibility

### SVG Data URI Cursors Support
- ✅ Chrome/Edge: Full support
- ✅ Firefox: Full support
- ✅ Safari: Full support
- ✅ Opera: Full support
- ⚠️ IE11: Fallback to crosshair cursor

### Fallback Behavior
If SVG cursor fails to load (rare), the browser uses the fallback `crosshair` cursor specified in the CSS.

## Testing Checklist

- [x] Eraser tool shows circle cursor (not crosshair)
- [x] Brush tool shows circle cursor
- [x] Cursor is visible on light backgrounds
- [x] Cursor is visible on dark backgrounds
- [x] Cursor hotspot is centered (drawing happens at cursor center)
- [x] Cursor doesn't flicker when moving
- [x] Switching between tools updates cursor correctly
- [x] Other tools (rectangle, circle, etc.) use default cursor

## Future Enhancements

### Dynamic Cursor Size Based on Brush Size
Could update the cursor to reflect actual brush size:

```typescript
useEffect(() => {
  if (!canvasRef.current) return;
  
  const size = Math.min(Math.max(brushSize * 2, 16), 64); // Clamp between 16-64px
  const radius = size / 2 - 2;
  const center = size / 2;
  
  const svgCursor = `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><circle cx="${center}" cy="${center}" r="${radius}" fill="none" stroke="black" stroke-width="1.5" opacity="0.6"/></svg>') ${center} ${center}, crosshair`;
  
  canvasRef.current.style.cursor = svgCursor;
}, [brushSize, drawingState.tool]);
```

**Not implemented yet:** Adds complexity, may impact performance, fixed size is sufficient for now.

## Files Modified

1. **src/index.css**
   - Added `.cursor-eraser` class with SVG circle cursor
   - Added `.cursor-brush` class with SVG circle cursor

2. **src/components/editor/canvas/FabricDrawingCanvas.tsx**
   - Applied cursor classes conditionally based on current tool
   - Removed Fabric.js `freeDrawingCursor` property settings

## Related Issues

- Improves user experience by providing visual feedback
- Makes eraser tool behavior consistent with industry standards (Canva, Figma, etc.)
- Reduces confusion about eraser size and position

## Version

- Fixed in: v106
- Related to: v105 (eraser color fix)
