# Fix Context Error - v135 Hotfix

## Issue

Error: `useSpriteEditor must be used within SpriteEditorProvider`

The error occurred because `SceneEditorPage` was trying to use the `useSpriteEditor` hook, but it wasn't wrapped in the `SpriteEditorProvider`. The provider only wraps the `SpriteEditor` component internally.

## Root Cause

In v135, I added:
```typescript
const { saveStatus } = useSpriteEditor();
```

to `SceneEditorPage.tsx` at the top level, but the `SpriteEditorProvider` is only available inside the `SpriteEditor` component, not at the page level.

## Solution

Moved the `TopToolbar` component inside `SpriteEditor` so it can access the context.

### Changes Made

**1. SpriteEditor.tsx**
- Added TopToolbar import
- Added props for mode, onModeChange, isPlaying, onPlayPause, onStop
- Destructured `saveStatus` from `useSpriteEditor` hook
- Rendered TopToolbar inside SpriteEditorContent (which has access to context)
- Passed saveStatus to TopToolbar

**2. SceneEditorPage.tsx**
- Removed `useSpriteEditor` import
- Removed `const { saveStatus } = useSpriteEditor()` call
- Removed TopToolbar from sprite mode render
- Passed TopToolbar props to SpriteEditor component
- Removed saveStatus prop from other TopToolbar instances (export/scene modes)

## Component Hierarchy

### Before (Broken)
```
SceneEditorPage
├─ useSpriteEditor() ❌ (no provider)
├─ TopToolbar (saveStatus prop)
└─ SpriteEditor
   └─ SpriteEditorProvider
      └─ SpriteEditorContent
```

### After (Fixed)
```
SceneEditorPage
└─ SpriteEditor
   └─ SpriteEditorProvider
      └─ SpriteEditorContent
         ├─ useSpriteEditor() ✅ (inside provider)
         └─ TopToolbar (saveStatus prop)
```

## Why This Works

- `TopToolbar` is now rendered inside `SpriteEditorContent`
- `SpriteEditorContent` is wrapped by `SpriteEditorProvider`
- `useSpriteEditor()` can now access the context
- `saveStatus` is available and passed to `TopToolbar`

## Save Status Behavior

- **Sprite Mode**: Shows actual save status (saved/saving/unsaved)
- **Scene Mode**: Shows default "All changes saved" (no saveStatus prop)
- **Export Mode**: Shows default "All changes saved" (no saveStatus prop)

This is correct because only sprite mode has the auto-save functionality.

## Testing

✅ Sprite mode loads without error
✅ Save status shows in header
✅ Scene mode loads without error
✅ Export mode loads without error
✅ All lint checks pass

## Files Modified

- `src/components/editor/SpriteEditor.tsx`
- `src/pages/SceneEditorPage.tsx`

## Lesson Learned

When using React Context:
1. Always check where the Provider is located
2. Only use the hook inside components wrapped by the Provider
3. If you need context data outside the provider, pass it as props
4. Or move the component inside the provider

