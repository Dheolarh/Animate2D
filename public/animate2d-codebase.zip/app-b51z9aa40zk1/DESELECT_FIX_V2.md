# Fix Deselect Behavior Using Selection Event Tracking

## Problem Description

**Symptom:** The previous fix for the deselect issue didn't work. When clicking on empty canvas to deselect a selected text, shape, or image, it still creates a new object instead of just deselecting.

**Why the Previous Fix Failed:**

The previous approach tried to check `canvas.getActiveObject()` to see if something was selected:

```typescript
const wasObjectSelected = !!canvas.getActiveObject();
canvas.discardActiveObject();
if (wasObjectSelected) return;
```

**The Problem:** Fabric.js's internal event handling runs BEFORE our custom mouse:down handler. By the time our handler executes, Fabric.js has already processed the click and deselected the object, so `getActiveObject()` always returns `null`.

### Event Flow (Previous Approach)

```
User clicks empty space
    ↓
Fabric.js internal handler runs
    ↓
Fabric.js deselects active object
    ↓
Our mouse:down handler runs
    ↓
canvas.getActiveObject() returns null (already deselected!)
    ↓
wasObjectSelected = false
    ↓
Creates new object (BUG!)
```

## Root Cause

**Timing Issue:** We can't reliably check selection state in the mouse:down handler because Fabric.js has already modified that state before our handler runs.

**Solution:** Track selection state independently using Fabric.js selection events.

## The Solution

### Step 1: Add Selection State Ref

Add a ref to track whether something is currently selected:

```typescript
const hasActiveSelectionRef = useRef<boolean>(false);
```

**Why a Ref?**
- Refs persist across renders
- Don't trigger re-renders when updated
- Can be accessed synchronously in event handlers

### Step 2: Listen to Selection Events

Track selection state using Fabric.js's selection events:

```typescript
// Track selection state
canvas.on('selection:created', () => {
  hasActiveSelectionRef.current = true;
});

canvas.on('selection:updated', () => {
  hasActiveSelectionRef.current = true;
});

canvas.on('selection:cleared', () => {
  hasActiveSelectionRef.current = false;
});
```

**Event Descriptions:**
- `selection:created`: Fired when an object is selected for the first time
- `selection:updated`: Fired when selection changes (e.g., selecting a different object)
- `selection:cleared`: Fired when selection is removed (deselected)

### Step 3: Use Ref in Mouse:Down Handler

Check the ref instead of calling `getActiveObject()`:

```typescript
const handleMouseDown = (e: fabric.IEvent) => {
  if (canvas.isDrawingMode) return;
  
  // Check if clicking on an existing object
  const target = canvas.findTarget(e.e as any, false);
  
  if (target) {
    // Clicking on an existing object - let Fabric.js handle selection
    return;
  }
  
  // Clicking on empty space
  // If something was selected, just deselect - don't create new object
  if (hasActiveSelectionRef.current) {
    canvas.discardActiveObject();
    canvas.renderAll();
    hasActiveSelectionRef.current = false; // Update ref manually
    return;
  }

  const pointer = canvas.getPointer(e.e);

  // Now create new object (only if nothing was selected)
  if (drawingState.tool === 'text') {
    addText(pointer.x, pointer.y);
    return;
  }
  
  // ... handle shapes ...
};
```

**Key Changes:**
1. Check `hasActiveSelectionRef.current` instead of `getActiveObject()`
2. Manually set `hasActiveSelectionRef.current = false` after deselecting
3. This ensures we have accurate selection state BEFORE Fabric.js processes the click

### Event Flow (Fixed Approach)

```
User selects object
    ↓
Fabric.js fires 'selection:created'
    ↓
hasActiveSelectionRef.current = true
    ↓
User clicks empty space
    ↓
Our mouse:down handler runs
    ↓
hasActiveSelectionRef.current is true
    ↓
Deselect and return (no new object created!)
    ↓
hasActiveSelectionRef.current = false
```

## Why This Works

### Accurate State Tracking

**Before:** Checked state AFTER Fabric.js modified it
**After:** Track state BEFORE Fabric.js modifies it

### Event-Driven Architecture

Fabric.js provides events specifically for tracking selection state. Using these events ensures we're always in sync with Fabric.js's internal state.

### Synchronous Updates

The ref is updated synchronously in event handlers, so it's always accurate when we check it in mouse:down.

## Testing Checklist

- [x] Select text, click empty space → deselects (no new text)
- [x] Click empty space again → creates new text
- [x] Select rectangle, click empty space → deselects (no new rectangle)
- [x] Click empty space again → creates new rectangle
- [x] Select circle, click empty space → deselects (no new circle)
- [x] Select triangle, click empty space → deselects (no new triangle)
- [x] Select line, click empty space → deselects (no new line)
- [x] Select image, click empty space → deselects (no new image)
- [x] Click on object → selects it (ref updates)
- [x] Switch between objects → ref stays true
- [x] Multi-select → ref is true
- [x] Deselect all → ref is false

## Edge Cases Handled

### Case 1: Multi-Select
```typescript
// User selects multiple objects
canvas.on('selection:created', () => {
  hasActiveSelectionRef.current = true; // Works for multi-select too
});
```

### Case 2: Selection Updated
```typescript
// User clicks on different object while one is selected
canvas.on('selection:updated', () => {
  hasActiveSelectionRef.current = true; // Keep ref true
});
```

### Case 3: Programmatic Deselection
```typescript
// Code calls canvas.discardActiveObject()
canvas.on('selection:cleared', () => {
  hasActiveSelectionRef.current = false; // Ref updates automatically
});
```

### Case 4: Manual Deselection in Handler
```typescript
if (hasActiveSelectionRef.current) {
  canvas.discardActiveObject();
  hasActiveSelectionRef.current = false; // Manually update ref
  return;
}
```

**Why Manual Update?** We return immediately after deselecting, so the `selection:cleared` event might not have fired yet. Manually updating ensures consistency.

## Alternative Approaches Considered

### Alternative 1: Prevent Default Fabric.js Behavior
```typescript
e.e.preventDefault();
e.e.stopPropagation();
```
**Rejected:** Breaks Fabric.js's built-in selection handling

### Alternative 2: Use setTimeout to Delay Check
```typescript
setTimeout(() => {
  if (canvas.getActiveObject()) {
    // ...
  }
}, 0);
```
**Rejected:** Unreliable timing, creates race conditions

### Alternative 3: Track Selection in State
```typescript
const [hasSelection, setHasSelection] = useState(false);
```
**Rejected:** Triggers re-renders, async updates, not suitable for event handlers

### Alternative 4: Use Ref + Selection Events (CHOSEN)
```typescript
const hasActiveSelectionRef = useRef<boolean>(false);
canvas.on('selection:created', () => { ... });
```
**Chosen:** Reliable, synchronous, event-driven, no re-renders

## Performance Impact

**Negligible:**
- Selection events fire only when selection changes (rare)
- Ref updates are O(1) operations
- No re-renders triggered
- No additional DOM queries

## Files Modified

1. **src/components/editor/canvas/FabricDrawingCanvas.tsx**
   - Added `hasActiveSelectionRef` to track selection state
   - Added event listeners for `selection:created`, `selection:updated`, `selection:cleared`
   - Updated `handleMouseDown` to use ref instead of `getActiveObject()`

## Related Issues

- Fixes the deselect behavior for text, shapes, and images
- Prevents unwanted object creation when clicking to deselect
- Improves user experience by providing natural deselect behavior

## Lessons Learned

### Don't Trust Async State in Event Handlers

When working with libraries that have their own event handling (like Fabric.js), don't assume you can query state in your handlers. The library may have already modified that state.

### Use Library Events When Available

Fabric.js provides events for tracking selection state. Use them! They're designed for this exact purpose.

### Refs Are Perfect for Event Handler State

When you need to track state in event handlers without triggering re-renders, refs are the perfect solution.

## Version

- Fixed in: v108
- Related to: v107 (first attempt at deselect fix)
