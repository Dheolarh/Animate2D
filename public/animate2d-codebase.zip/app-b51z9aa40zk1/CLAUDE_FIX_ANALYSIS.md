# Claude's Critical Fix for Selection/Deselection Bug

## The Problem Claude Identified

The deselect bug persisted because of **two critical issues**:

### Issue 1: Timing Problem
By the time our `mouse:down` handler checked `hasActiveSelectionRef.current`, Fabric.js had already processed the click and cleared the selection, so the ref was already `false`.

### Issue 2: No Drag Detection
The code created shapes/lines immediately in `mouse:down`, which meant even a click to deselect would start creating a shape.

## Claude's Solution

### Fix 1: Capture State at the Very Start

**Before (Wrong):**
```typescript
const handleMouseDown = (e: fabric.IEvent) => {
  const target = canvas.findTarget(e.e as any, false);
  
  // By this point, Fabric.js may have already cleared selection!
  if (hasActiveSelectionRef.current) {
    // This check is too late
  }
}
```

**After (Correct):**
```typescript
const handleMouseDown = (e: fabric.IEvent) => {
  // ✅ Capture BEFORE Fabric.js processes anything
  const hadActiveSelection = hasActiveSelectionRef.current;
  const target = canvas.findTarget(e.e as any, false);
  
  if (target) return;
  
  // Use the captured value
  if (hadActiveSelection) {
    canvas.discardActiveObject();
    hasActiveSelectionRef.current = false;
    canvas.renderAll();
    return; // ← STOP HERE
  }
}
```

### Fix 2: Implement Drag Detection

**Add these refs:**
```typescript
const mouseDownPositionRef = useRef<{ x: number; y: number } | null>(null);
const DRAG_THRESHOLD = 5; // pixels
```

**In mouse:down:**
```typescript
const handleMouseDown = (e: fabric.IEvent) => {
  // ... capture state ...
  
  const pointer = canvas.getPointer(e.e);
  mouseDownPositionRef.current = { x: pointer.x, y: pointer.y };
  
  // Handle text immediately (click-to-create)
  if (drawingState.tool === 'text') {
    addText(pointer.x, pointer.y);
    mouseDownPositionRef.current = null;
    return;
  }
  
  // For shapes/lines, wait for mouse:move
}
```

**In mouse:move:**
```typescript
const handleMouseMove = (e: fabric.IEvent) => {
  const pointer = canvas.getPointer(e.e);
  
  // Check if we should start drawing
  if (mouseDownPositionRef.current && !isDrawing) {
    const dx = Math.abs(pointer.x - mouseDownPositionRef.current.x);
    const dy = Math.abs(pointer.y - mouseDownPositionRef.current.y);
    const isDragging = dx > DRAG_THRESHOLD || dy > DRAG_THRESHOLD;
    
    if (isDragging) {
      // NOW start creating shape/line
      const startX = mouseDownPositionRef.current.x;
      const startY = mouseDownPositionRef.current.y;
      // ... create shape/line at start position ...
    }
  }
  
  // Continue updating during drag
  // ... existing drawing logic ...
}
```

**In mouse:up:**
```typescript
const handleMouseUp = () => {
  mouseDownPositionRef.current = null; // Reset
  
  // ... rest of logic ...
}
```

## The Three Cases

Claude's fix properly handles three distinct cases:

### Case 1: Clicking on an Object
```typescript
if (target) return; // Let Fabric.js handle it
```

### Case 2: Clicking Empty Space with Selection
```typescript
if (hadActiveSelection) {
  canvas.discardActiveObject();
  hasActiveSelectionRef.current = false;
  canvas.renderAll();
  return; // Don't create new object
}
```

### Case 3: Clicking Empty Space without Selection
```typescript
// Text: Create immediately
if (drawingState.tool === 'text') {
  addText(pointer.x, pointer.y);
  return;
}

// Shapes/Lines: Wait for drag in mouse:move
```

## Key Insights

### 1. Timing is Everything
The ref value was correct, but we were checking it too late. By capturing `hadActiveSelection` at the very start of the handler, we get the state BEFORE Fabric.js modifies it.

### 2. Click vs Drag
- **Text**: Click-to-create (handled in mouse:down)
- **Shapes/Lines**: Drag-to-create (handled in mouse:move after threshold)

### 3. Drag Threshold
A 5-pixel threshold prevents accidental shape creation from tiny hand movements while still allowing intentional drags.

## Testing Results

With Claude's fix:

✅ **Text Tool:**
- Click empty space → creates text
- Click empty space with selected text → deselects (no new text)

✅ **Shape Tools:**
- Click and release immediately → nothing happens
- Click and drag → creates shape
- Click empty space with selected shape → deselects (no new shape)

✅ **Line Tool:**
- Click and release immediately → nothing happens
- Click and drag → creates line
- Click empty space with selected line → deselects (no new line)

## Summary Table

| Problem | Previous Approach | Claude's Fix |
|---------|------------------|--------------|
| Timing | Checked ref after Fabric.js processed | Capture `hadActiveSelection` at start |
| Drag Detection | Created shapes in mouse:down | Move to mouse:move after threshold |
| Text Tool | Same as shapes | Keep in mouse:down (click-to-create) |
| Result | Bug persisted | Bug fixed ✅ |

## Implementation Checklist

- [x] Add `mouseDownPositionRef` and `DRAG_THRESHOLD`
- [x] Capture `hadActiveSelection` at start of mouse:down
- [x] Store mouse position in mouse:down
- [x] Handle text immediately in mouse:down
- [x] Add drag detection in mouse:move
- [x] Move shape/line creation to mouse:move
- [x] Reset `mouseDownPositionRef` in mouse:up
- [x] Test all three cases thoroughly

## Files Modified

1. **src/components/editor/canvas/FabricDrawingCanvas.tsx**
   - Added `mouseDownPositionRef` and `DRAG_THRESHOLD`
   - Updated `handleMouseDown` to capture state early
   - Updated `handleMouseMove` with drag detection
   - Updated `handleMouseUp` to reset position ref

## Version

- Fixed in: v113
- Based on: Claude's analysis and recommendations
- Related: v108-v112 (previous attempts)

## Credit

This fix is based on Claude's detailed analysis which identified the root cause: timing and lack of drag detection. The key insight was that we needed to capture the selection state BEFORE Fabric.js processes the event, not after.
