import React, { createContext, useContext, useState, useRef, ReactNode } from 'react';
import type { FrameImage, FrameText } from '@/types/animation';
import type { Tool, DrawingState, CanvasState, AnimationSettings } from '../types/spriteEditor';

export interface UploadedImage {
  id: string;
  url: string;
  name: string;
  width: number;
  height: number;
}

interface SpriteEditorContextType {
  // Drawing state
  drawingState: DrawingState;
  setDrawingState: (state: DrawingState) => void;
  setTool: (tool: Tool) => void;
  setColor: (color: string) => void;
  setBrushSize: (size: number) => void;
  setOpacity: (opacity: number) => void;

  // Canvas state
  canvasState: CanvasState;
  setCanvasState: (state: CanvasState) => void;
  setShowTransparentFrame: (show: boolean) => void;
  setCanvasSize: (width: number, height: number) => void;

  // Animation settings
  animationSettings: AnimationSettings;
  setAnimationSettings: (settings: AnimationSettings) => void;

  // Onion skin settings
  onionSkinFrameCount: number;
  setOnionSkinFrameCount: (count: number) => void;

  // Save status
  saveStatus: 'saved' | 'saving' | 'unsaved';
  setSaveStatus: (status: 'saved' | 'saving' | 'unsaved') => void;

  // Image gallery state
  uploadedImages: UploadedImage[];
  setUploadedImages: React.Dispatch<React.SetStateAction<UploadedImage[]>>;
  selectedImage: FrameImage | null;
  setSelectedImage: (image: FrameImage | null) => void;
  selectedText: FrameText | null;
  setSelectedText: (text: FrameText | null) => void;
  draggingImageUrl: string | null;
  setDraggingImageUrl: (url: string | null) => void;
}

const SpriteEditorContext = createContext<SpriteEditorContextType | undefined>(undefined);

export const useSpriteEditor = () => {
  const context = useContext(SpriteEditorContext);
  if (!context) {
    throw new Error('useSpriteEditor must be used within SpriteEditorProvider');
  }
  return context;
};

interface SpriteEditorProviderProps {
  children: ReactNode;
}

export const SpriteEditorProvider: React.FC<SpriteEditorProviderProps> = ({ children }) => {
  // Drawing state
  const [drawingState, setDrawingState] = useState<DrawingState>({
    tool: 'brush',
    color: '#000000',
    brushSize: 3,
    opacity: 1,
    isDrawing: false
  });

  // Canvas state
  const [canvasState, setCanvasState] = useState<CanvasState>({
    width: 512,
    height: 512,
    showTransparentFrame: true, // Enable onion skinning by default
    backgroundColor: '#ffffff'
  });

  // Animation settings
  const [animationSettings, setAnimationSettings] = useState<AnimationSettings>({
    name: 'New Animation',
    fps: 12
  });

  // Onion skin settings
  const [onionSkinFrameCount, setOnionSkinFrameCount] = useState<number>(5);

  // Save status
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');

  // Image gallery state
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [selectedImage, setSelectedImage] = useState<FrameImage | null>(null);
  const [selectedText, setSelectedText] = useState<FrameText | null>(null);
  const [draggingImageUrl, setDraggingImageUrl] = useState<string | null>(null);

  // Helper setters
  const setTool = (tool: Tool) => {
    setDrawingState(prev => ({ ...prev, tool }));
  };

  const setColor = (color: string) => {
    setDrawingState(prev => ({ ...prev, color }));
  };

  const setBrushSize = (size: number) => {
    setDrawingState(prev => ({ ...prev, brushSize: size }));
  };

  const setOpacity = (opacity: number) => {
    setDrawingState(prev => ({ ...prev, opacity }));
  };

  const setShowTransparentFrame = (show: boolean) => {
    setCanvasState(prev => ({ ...prev, showTransparentFrame: show }));
  };

  const setCanvasSize = (width: number, height: number) => {
    setCanvasState(prev => ({ ...prev, width, height }));
  };

  const value: SpriteEditorContextType = {
    drawingState,
    setDrawingState,
    setTool,
    setColor,
    setBrushSize,
    setOpacity,
    canvasState,
    setCanvasState,
    setShowTransparentFrame,
    setCanvasSize,
    animationSettings,
    setAnimationSettings,
    onionSkinFrameCount,
    setOnionSkinFrameCount,
    saveStatus,
    setSaveStatus,
    uploadedImages,
    setUploadedImages,
    selectedImage,
    setSelectedImage,
    selectedText,
    setSelectedText,
    draggingImageUrl,
    setDraggingImageUrl
  };

  return (
    <SpriteEditorContext.Provider value={value}>
      {children}
    </SpriteEditorContext.Provider>
  );
};
