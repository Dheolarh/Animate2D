export type Tool = 'pencil' | 'brush' | 'eraser' | 'line' | 'rectangle' | 'circle' | 'triangle' | 'fill' | 'smudge' | 'blur' | 'glow' | 'text' | 'image';

export interface DrawingState {
  tool: Tool;
  color: string;
  brushSize: number;
  opacity: number;
  isDrawing: boolean;
}

export interface CanvasState {
  width: number;
  height: number;
  showTransparentFrame: boolean;
  backgroundColor: string;
}

export interface AnimationSettings {
  name: string;
  fps: number;
}
