import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as fabric from 'fabric';
import { EraserBrush } from 'erase2d';
import { useSpriteEditor } from '../context/SpriteEditorContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Pencil, 
  Eraser, 
  Square, 
  Circle, 
  Triangle, 
  Type,
  Image as ImageIcon,
  Trash2,
  Lock,
  Unlock
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  saveCanvasVersion,
  revertToPreviousVersion,
  redoToNextVersion,
  getCurrentVersion,
  getVersionInfo,
  loadCanvasSaves
} from '@/utils/canvas-save';

const FabricDrawingCanvas: React.FC = () => {
  const {
    canvasState,
    setCanvasState,
    drawingState,
    setDrawingState,
    setTool,
    onionSkinFrameCount,
    saveStatus,
    setSaveStatus
  } = useSpriteEditor();

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvasRef = useRef<fabric.Canvas | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Simple counter: 0 = nothing selected, 1 = something selected
  const selectionCountRef = useRef<number>(0);
  
  const mouseDownPositionRef = useRef<{ x: number; y: number } | null>(null);
  const DRAG_THRESHOLD = 5;
  const [zoom, setZoom] = useState(50);
  const [showOnionSkin, setShowOnionSkin] = useState(true); // Default to true
  const [shapeFillMode, setShapeFillMode] = useState<'fill' | 'stroke'>('stroke');
  const [panAxis, setPanAxis] = useState<'x' | 'y'>('x');
  const [panValue, setPanValue] = useState(0);
  const [canvasPosition, setCanvasPosition] = useState({ x: 0, y: 0 });
  const [isDraggingCanvas, setIsDraggingCanvas] = useState(false);
  const canvasDragStartRef = useRef<{ x: number; y: number; canvasX: number; canvasY: number } | null>(null);
  const autoSaveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [hasSelection, setHasSelection] = useState(false);
  const [isSelectedObjectLocked, setIsSelectedObjectLocked] = useState(false);
  const lineDrawingRef = useRef<{ isDrawing: boolean; line: fabric.Line | null }>({ isDrawing: false, line: null });
  const shapeDrawingRef = useRef<{ isDrawing: boolean; shape: fabric.Object | null; startX: number; startY: number }>({ 
    isDrawing: false, 
    shape: null, 
    startX: 0, 
    startY: 0 
  });

  // Undo/Redo history
  const historyRef = useRef<string[]>([]);
  const historyStepRef = useRef<number>(-1);
  const isUndoRedoRef = useRef<boolean>(false);
  const MAX_HISTORY = 50;

  // Panning state
  const isPanningRef = useRef<boolean>(false);
  const lastPanPointRef = useRef<{ x: number; y: number } | null>(null);

  // Auto-save function with debounce
  const autoSaveCanvas = useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    // Clear existing timeout
    if (autoSaveTimeoutRef.current) {
      clearTimeout(autoSaveTimeoutRef.current);
    }

    // Set saving status
    setSaveStatus('unsaved');

    // Debounce: save after 500ms of inactivity
    autoSaveTimeoutRef.current = setTimeout(() => {
      setSaveStatus('saving');
      
      try {
        // Get all objects for debugging
        const allObjects = canvas.getObjects();
        console.log('[AUTO-SAVE] Saving canvas with', allObjects.length, 'objects');
        console.log('[AUTO-SAVE] Object types:', allObjects.map(obj => obj.type));
        
        // Save canvas - toJSON() includes all objects and properties
        const canvasData = canvas.toJSON();
        const canvasJSON = JSON.stringify(canvasData);
        
        console.log('[AUTO-SAVE] Canvas JSON length:', canvasJSON.length);
        console.log('[AUTO-SAVE] Objects in JSON:', canvasData.objects?.length || 0);
        
        saveCanvasVersion(
          canvasState.width,
          canvasState.height,
          canvasState.backgroundColor || '#ffffff',
          0, // Frame number (placeholder)
          canvasJSON
        );
        
        setSaveStatus('saved');
        console.log('[AUTO-SAVE] Canvas saved successfully');
      } catch (error) {
        console.error('[AUTO-SAVE] Failed to save:', error);
        setSaveStatus('unsaved');
      }
    }, 500);
  }, [canvasState.width, canvasState.height, canvasState.backgroundColor]);

  // Load canvas from version
  const loadCanvasFromVersion = useCallback((versionData: string) => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    try {
      const parsedData = JSON.parse(versionData);
      console.log('[VERSION] Loading canvas with', parsedData.objects?.length || 0, 'objects');
      console.log('[VERSION] Object types:', parsedData.objects?.map((obj: any) => obj.type));
      
      canvas.loadFromJSON(parsedData, () => {
        const loadedObjects = canvas.getObjects();
        console.log('[VERSION] Canvas loaded with', loadedObjects.length, 'objects');
        console.log('[VERSION] Loaded object types:', loadedObjects.map(obj => obj.type));
        canvas.renderAll();
        console.log('[VERSION] Canvas loaded from version');
      });
    } catch (error) {
      console.error('[VERSION] Failed to load canvas:', error);
    }
  }, []);

  // Initialize Fabric canvas
  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = new fabric.Canvas(canvasRef.current, {
      width: canvasState.width,
      height: canvasState.height,
      backgroundColor: canvasState.backgroundColor || '#ffffff',
      preserveObjectStacking: true,
      selection: false, // Disable multi-select box
    });

    // Style the selection controls - CRITICAL: Set on prototype before creating objects
    fabric.Object.prototype.set({
      borderColor: 'rgba(0, 0, 0, 0.6)',
      cornerColor: 'rgba(0, 0, 0, 0.9)',
      cornerStyle: 'circle',
      cornerSize: 12,
      transparentCorners: false,
      borderScaleFactor: 2,
      padding: 8,
      borderDashArray: [5, 5],
      // CRITICAL: Make all objects erasable by default
      erasable: true,
      // CRITICAL: Keep stroke width constant when scaling
      strokeUniform: true,
    });

    fabricCanvasRef.current = canvas;

    // Lock brush paths immediately on creation (but NOT eraser paths)
    // This prevents brush strokes from being selectable
    canvas.on('path:created', (e: any) => {
      const path: fabric.Path = e.path;
      
      // Check if this is an eraser path - don't lock it
      // Eraser paths need to be processed by erase2d
      if ((path as any).isEraser || (canvas.freeDrawingBrush as any).constructor.name === 'EraserBrush') {
        console.log('[ERASER] Eraser path created, not locking');
        // Auto-save after eraser stroke
        autoSaveCanvas();
        return;
      }
      
      // Lock brush paths completely - they should never be selectable
      path.set({
        selectable: false,
        evented: false,
        hasControls: false,
        hasBorders: false,
        lockMovementX: true,
        lockMovementY: true,
        lockRotation: true,
        lockScalingX: true,
        lockScalingY: true,
        erasable: true, // Make brush strokes erasable
      });
      
      // Tag it so we can identify it later if needed
      (path as any).__locked__ = true;
      
      // Discard any active selection to prevent flash
      canvas.discardActiveObject();
      canvas.renderAll();
      
      // Auto-save after brush stroke
      autoSaveCanvas();
    });

    // Auto-save on object modification
    canvas.on('object:modified', () => {
      canvas.renderAll();
      autoSaveCanvas();
    });

    // Auto-save on object added
    canvas.on('object:added', () => {
      autoSaveCanvas();
    });

    // Auto-save on object removed
    canvas.on('object:removed', () => {
      autoSaveCanvas();
    });

    // Track selection state with simple counter
    canvas.on('selection:created', (e) => {
      console.log('[SELECTION] Count: 0 → 1 (object selected)');
      selectionCountRef.current = 1;
      setHasSelection(true);
      
      // Check if selected object is locked
      const activeObject = e.selected?.[0];
      if (activeObject) {
        setIsSelectedObjectLocked(activeObject.lockMovementX === true);
      }
    });
    
    canvas.on('selection:updated', (e) => {
      console.log('[SELECTION] Count: 1 (selection updated)');
      selectionCountRef.current = 1;
      setHasSelection(true);
      
      // Check if selected object is locked
      const activeObject = e.selected?.[0];
      if (activeObject) {
        setIsSelectedObjectLocked(activeObject.lockMovementX === true);
      }
    });
    
    canvas.on('selection:cleared', () => {
      console.log('[SELECTION] Count: 1 → 0 (deselected)');
      selectionCountRef.current = 0;
      setHasSelection(false);
      setIsSelectedObjectLocked(false);
    });

    // Load latest version or save initial state
    setTimeout(() => {
      const currentVersion = getCurrentVersion();
      if (currentVersion) {
        loadCanvasFromVersion(currentVersion.canvasData.objects);
        console.log('[INIT] Loaded latest version:', currentVersion.version);
      } else {
        autoSaveCanvas();
        console.log('[INIT] Created initial save');
      }
    }, 100);

    // Cleanup
    return () => {
      canvas.dispose();
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
    };
  }, [autoSaveCanvas, loadCanvasFromVersion]);

  // Sync panValue with canvasPosition when axis changes
  useEffect(() => {
    setPanValue(panAxis === 'x' ? canvasPosition.x : canvasPosition.y);
  }, [panAxis, canvasPosition.x, canvasPosition.y]);

  // History management functions
  const saveHistory = React.useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas || isUndoRedoRef.current) return;

    const json = JSON.stringify(canvas.toJSON());
    
    // Remove any redo history
    historyRef.current = historyRef.current.slice(0, historyStepRef.current + 1);
    
    // Add new state
    historyRef.current.push(json);
    
    // Limit history size
    if (historyRef.current.length > MAX_HISTORY) {
      historyRef.current.shift();
    } else {
      historyStepRef.current++;
    }
    
    console.log('[HISTORY] Saved state, step:', historyStepRef.current, 'total:', historyRef.current.length);
  }, []);

  // Undo: Revert to previous version (Ctrl+Z)
  const undo = useCallback(() => {
    const previousVersion = revertToPreviousVersion();
    if (!previousVersion) {
      console.log('[UNDO] No previous version available');
      return;
    }

    loadCanvasFromVersion(previousVersion.canvasData.objects);
    console.log('[UNDO] Reverted to version:', previousVersion.version);
  }, [loadCanvasFromVersion]);

  // Redo: Go to next version (Ctrl+Y)
  const redo = useCallback(() => {
    const nextVersion = redoToNextVersion();
    if (!nextVersion) {
      console.log('[REDO] No next version available');
      return;
    }

    loadCanvasFromVersion(nextVersion.canvasData.objects);
    console.log('[REDO] Restored to version:', nextVersion.version);
  }, [loadCanvasFromVersion]);

  // Delete selected object
  const deleteSelected = React.useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const activeObjects = canvas.getActiveObjects();
    if (activeObjects.length > 0) {
      activeObjects.forEach((obj) => canvas.remove(obj));
      canvas.discardActiveObject();
      canvas.renderAll();
    }
  }, []);

  // Lock/unlock selected objects
  const toggleLockSelected = React.useCallback(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const activeObjects = canvas.getActiveObjects();
    if (activeObjects.length > 0) {
      // Check if currently locked (lockMovementX is true means locked)
      const isCurrentlyLocked = activeObjects[0].lockMovementX === true;
      
      activeObjects.forEach((obj) => {
        if (isCurrentlyLocked) {
          // Unlock: allow movement and scaling
          obj.set({
            selectable: true,
            evented: true,
            hasControls: true,
            hasBorders: true,
            lockMovementX: false,
            lockMovementY: false,
            lockRotation: false,
            lockScalingX: false,
            lockScalingY: false,
          });
        } else {
          // Lock: keep selectable but prevent movement and scaling
          obj.set({
            selectable: true,
            evented: true,
            hasControls: false,
            hasBorders: true,
            lockMovementX: true,
            lockMovementY: true,
            lockRotation: true,
            lockScalingX: true,
            lockScalingY: true,
          });
        }
      });
      
      // Update lock state
      setIsSelectedObjectLocked(!isCurrentlyLocked);
      
      canvas.renderAll();
      console.log('[LOCK] Objects', isCurrentlyLocked ? 'unlocked' : 'locked');
    }
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts if user is typing in an input field
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        return;
      }

      const activeObject = canvas.getActiveObject();

      // Undo - Ctrl+Z / Cmd+Z
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
        return;
      }

      // Redo - Ctrl+Y / Cmd+Y or Ctrl+Shift+Z / Cmd+Shift+Z
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
        e.preventDefault();
        redo();
        return;
      }

      // Delete key - Delete selected object
      if ((e.key === 'Delete' || e.key === 'Backspace') && activeObject) {
        e.preventDefault();
        deleteSelected();
        return;
      }

      // Lock/Unlock - Ctrl+L / Cmd+L
      if ((e.ctrlKey || e.metaKey) && e.key === 'l' && activeObject) {
        e.preventDefault();
        toggleLockSelected();
        return;
      }

      // Escape - Deselect
      if (e.key === 'Escape') {
        e.preventDefault();
        canvas.discardActiveObject();
        selectionCountRef.current = 0;
        canvas.renderAll();
        return;
      }

      // Arrow keys - Move selected object
      if (activeObject && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault();
        const step = e.shiftKey ? 10 : 1; // Shift for larger steps
        
        switch (e.key) {
          case 'ArrowUp':
            activeObject.set({ top: (activeObject.top || 0) - step });
            break;
          case 'ArrowDown':
            activeObject.set({ top: (activeObject.top || 0) + step });
            break;
          case 'ArrowLeft':
            activeObject.set({ left: (activeObject.left || 0) - step });
            break;
          case 'ArrowRight':
            activeObject.set({ left: (activeObject.left || 0) + step });
            break;
        }
        
        activeObject.setCoords();
        canvas.renderAll();
        return;
      }

      // Tool shortcuts (only if no modifier keys)
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        switch (e.key.toLowerCase()) {
          case 'b':
            e.preventDefault();
            setTool('brush');
            break;
          case 'e':
            e.preventDefault();
            setTool('eraser');
            break;
          case 'r':
            e.preventDefault();
            setTool('rectangle');
            break;
          case 'c':
            e.preventDefault();
            setTool('circle');
            break;
          case 't':
            e.preventDefault();
            setTool('text');
            break;
          case 'l':
            e.preventDefault();
            setTool('line');
            break;
          case 'i':
            e.preventDefault();
            setTool('image');
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [setTool, undo, redo, deleteSelected, toggleLockSelected]);

  // Mouse wheel zoom and right-click panning
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    const canvasElement = canvasRef.current;
    if (!canvas || !canvasElement) return;

    // Mouse wheel zoom
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      
      const delta = e.deltaY;
      let newZoom = canvas.getZoom();
      
      // Zoom in/out
      if (delta < 0) {
        newZoom *= 1.1; // Zoom in
      } else {
        newZoom /= 1.1; // Zoom out
      }
      
      // Limit zoom range
      newZoom = Math.max(0.1, Math.min(5, newZoom));
      
      // Zoom towards mouse cursor
      const point = new fabric.Point(e.offsetX, e.offsetY);
      canvas.zoomToPoint(point, newZoom);
      
      // Update zoom state for UI
      setZoom(Math.round(newZoom * 100));
      
      console.log('[ZOOM] New zoom:', Math.round(newZoom * 100) + '%');
    };

    // Right-click panning
    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 2) { // Right mouse button
        e.preventDefault();
        isPanningRef.current = true;
        lastPanPointRef.current = { x: e.clientX, y: e.clientY };
        canvas.selection = false; // Disable selection while panning
        canvasElement.style.cursor = 'grab';
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isPanningRef.current && lastPanPointRef.current) {
        const vpt = canvas.viewportTransform;
        if (vpt) {
          vpt[4] += e.clientX - lastPanPointRef.current.x;
          vpt[5] += e.clientY - lastPanPointRef.current.y;
          canvas.requestRenderAll();
          lastPanPointRef.current = { x: e.clientX, y: e.clientY };
        }
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 2 && isPanningRef.current) {
        isPanningRef.current = false;
        lastPanPointRef.current = null;
        canvas.selection = true; // Re-enable selection
        canvasElement.style.cursor = 'default';
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault(); // Prevent context menu
      e.stopPropagation(); // Stop event bubbling
      return false;
    };

    // Add event listeners with capture to ensure they fire first
    canvasElement.addEventListener('wheel', handleWheel, { passive: false });
    canvasElement.addEventListener('mousedown', handleMouseDown, true); // Use capture
    canvasElement.addEventListener('mousemove', handleMouseMove);
    canvasElement.addEventListener('mouseup', handleMouseUp);
    canvasElement.addEventListener('contextmenu', handleContextMenu, true); // Use capture

    // Also add to window for mouseup (in case mouse leaves canvas)
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      canvasElement.removeEventListener('wheel', handleWheel);
      canvasElement.removeEventListener('mousedown', handleMouseDown, true);
      canvasElement.removeEventListener('mousemove', handleMouseMove);
      canvasElement.removeEventListener('mouseup', handleMouseUp);
      canvasElement.removeEventListener('contextmenu', handleContextMenu, true);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  // Canvas dragging with Space key
  useEffect(() => {
    const containerElement = containerRef.current;
    if (!containerElement) return;

    let isSpacePressed = false;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !isSpacePressed) {
        isSpacePressed = true;
        containerElement.style.cursor = 'grab';
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        isSpacePressed = false;
        setIsDraggingCanvas(false);
        containerElement.style.cursor = 'default';
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      // Middle mouse button or Space + left click
      if (e.button === 1 || (isSpacePressed && e.button === 0)) {
        e.preventDefault();
        setIsDraggingCanvas(true);
        canvasDragStartRef.current = {
          x: e.clientX,
          y: e.clientY,
          canvasX: canvasPosition.x,
          canvasY: canvasPosition.y,
        };
        containerElement.style.cursor = 'grabbing';
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isDraggingCanvas && canvasDragStartRef.current) {
        const deltaX = e.clientX - canvasDragStartRef.current.x;
        const deltaY = e.clientY - canvasDragStartRef.current.y;
        
        setCanvasPosition({
          x: canvasDragStartRef.current.canvasX + deltaX,
          y: canvasDragStartRef.current.canvasY + deltaY,
        });
      }
    };

    const handleMouseUp = () => {
      if (isDraggingCanvas) {
        setIsDraggingCanvas(false);
        containerElement.style.cursor = isSpacePressed ? 'grab' : 'default';
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    containerElement.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      containerElement.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDraggingCanvas, canvasPosition]);

  // Update background color when it changes
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const newBgColor = canvasState.backgroundColor || '#ffffff';
    canvas.backgroundColor = newBgColor;
    canvas.renderAll();
  }, [canvasState.backgroundColor, drawingState.tool]);

  // Update canvas dimensions when they change
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    canvas.setDimensions({
      width: canvasState.width,
      height: canvasState.height
    });
    
    canvas.renderAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canvasState.width, canvasState.height]);

  // Update drawing mode when tool changes
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const isDrawingTool = ['brush', 'eraser'].includes(drawingState.tool);

    if (isDrawingTool) {
      canvas.isDrawingMode = true;
      canvas.selection = false; // Disable multi-select box

      if (drawingState.tool === 'brush') {
        const brush = new fabric.PencilBrush(canvas);
        brush.color = drawingState.color;
        brush.width = drawingState.brushSize;
        // Set opacity on the brush object itself
        (brush as any).opacity = drawingState.opacity / 100;
        canvas.freeDrawingBrush = brush;
      } else if (drawingState.tool === 'eraser') {
        // Use EraserBrush from erase2d library
        // This provides proper eraser functionality for Fabric.js
        const eraser = new EraserBrush(canvas);
        eraser.width = drawingState.brushSize;
        eraser.color = 'black'; // Color doesn't matter for erasing, but required
        
        // Log when erasing starts
        eraser.on('start', () => {
          console.log('[ERASER] Started erasing');
        });
        
        // Log when erasing ends
        eraser.on('end', (e: any) => {
          console.log('[ERASER] Finished erasing, targets:', e.detail?.targets?.length || 0);
          // Don't prevent default - let erase2d commit the erasing
        });
        
        canvas.freeDrawingBrush = eraser;
        console.log('[ERASER] EraserBrush from erase2d initialized');
      }
      
      // Make all objects non-selectable in drawing mode
      canvas.getObjects().forEach((obj: fabric.FabricObject) => {
        if ((obj as any).__locked__) return;
        obj.set({
          selectable: false,
          evented: false,
        });
      });
    } else {
      canvas.isDrawingMode = false;
      // Disable multi-select box for all tools
      canvas.selection = false;
      
      // Make all objects selectable for single selection
      canvas.getObjects().forEach((obj: fabric.FabricObject) => {
        if ((obj as any).__locked__) return;
        obj.set({
          selectable: true,
          evented: true,
        });
      });
    }
    
    canvas.renderAll();
  }, [drawingState.tool, drawingState.color, drawingState.brushSize, drawingState.opacity, canvasState.backgroundColor]);

  // Handle canvas mouse events for adding objects
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const handleMouseDown = (opt: fabric.TPointerEventInfo) => {
      console.log('[MOUSE DOWN] isDrawingMode:', canvas.isDrawingMode);
      if (canvas.isDrawingMode) return;
      
      const e = opt.e;
      const pointer = canvas.getScenePoint(e);
      const target = canvas.findTarget(e);
      
      console.log('[MOUSE DOWN] Count:', selectionCountRef.current, 'Target:', !!target, 'Tool:', drawingState.tool);
      
      // Store mouse down position for drag detection
      mouseDownPositionRef.current = { x: pointer.x, y: pointer.y };
      
      // Case 1: Clicking on an existing object → let Fabric.js handle selection
      if (target) {
        console.log('[MOUSE DOWN] Clicking on object');
        return;
      }
      
      // Special case: Text tool always creates text when clicking empty space
      if (drawingState.tool === 'text') {
        console.log('[MOUSE DOWN] Text tool, adding text');
        // Deselect any selected object first
        if (selectionCountRef.current > 0) {
          canvas.discardActiveObject();
          selectionCountRef.current = 0;
        }
        addText(pointer.x, pointer.y);
        mouseDownPositionRef.current = null;
        return;
      }
      
      // Case 2: Count = 1 (something selected) → ONLY deselect, do NOT create
      if (selectionCountRef.current === 1) {
        console.log('[MOUSE DOWN] Count is 1, deselecting only');
        canvas.discardActiveObject();
        selectionCountRef.current = 0;
        canvas.renderAll();
        return; // ← STOP HERE
      }
      
      // Case 3: Count = 0 (nothing selected) → can create new object
      console.log('[MOUSE DOWN] Count is 0, can create object, tool:', drawingState.tool);
      
      // For shapes and lines, wait for mouse:move to confirm it's a drag
    };

    const handleMouseMove = (opt: fabric.TPointerEventInfo) => {
      const e = opt.e;
      const pointer = canvas.getScenePoint(e);
      
      // Check if we should start drawing (drag detection)
      // Only start if count = 0 (nothing selected)
      if (mouseDownPositionRef.current && !lineDrawingRef.current.isDrawing && !shapeDrawingRef.current.isDrawing && selectionCountRef.current === 0) {
        const dx = Math.abs(pointer.x - mouseDownPositionRef.current.x);
        const dy = Math.abs(pointer.y - mouseDownPositionRef.current.y);
        const isDragging = dx > DRAG_THRESHOLD || dy > DRAG_THRESHOLD;
        
        if (isDragging) {
          console.log('[MOUSE MOVE] Drag detected, count is 0, starting drawing');
          const startX = mouseDownPositionRef.current.x;
          const startY = mouseDownPositionRef.current.y;
          
          // Start line drawing
          if (drawingState.tool === 'line') {
            lineDrawingRef.current.isDrawing = true;
            const line = new fabric.Line([startX, startY, pointer.x, pointer.y], {
              stroke: drawingState.color,
              strokeWidth: drawingState.brushSize,
              strokeUniform: true, // Keep stroke width constant when scaling
              fill: '',
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
            });
            canvas.add(line);
            lineDrawingRef.current.line = line;
            canvas.renderAll();
          }
          
          // Start shape drawing
          if (['rectangle', 'circle', 'triangle'].includes(drawingState.tool)) {
            shapeDrawingRef.current.isDrawing = true;
            shapeDrawingRef.current.startX = startX;
            shapeDrawingRef.current.startY = startY;
            
            let shape: fabric.Object;
            
            const shapeConfig = {
              fill: shapeFillMode === 'fill' ? drawingState.color : '',
              stroke: shapeFillMode === 'stroke' ? drawingState.color : '',
              strokeWidth: shapeFillMode === 'stroke' ? drawingState.brushSize : 0,
              strokeUniform: true, // Keep stroke width constant when scaling
              selectable: false,
              evented: false,
              hasControls: false,
              hasBorders: false,
            };
            
            switch (drawingState.tool) {
              case 'rectangle':
                shape = new fabric.Rect({
                  left: startX,
                  top: startY,
                  width: 0,
                  height: 0,
                  ...shapeConfig,
                });
                break;
              case 'circle':
                shape = new fabric.Circle({
                  left: startX,
                  top: startY,
                  radius: 0,
                  ...shapeConfig,
                });
                break;
              case 'triangle':
                shape = new fabric.Triangle({
                  left: startX,
                  top: startY,
                  width: 0,
                  height: 0,
                  ...shapeConfig,
                });
                break;
              default:
                return;
            }
            
            canvas.add(shape);
            shapeDrawingRef.current.shape = shape;
            canvas.renderAll();
          }
        }
      }

      // Handle line drawing
      if (lineDrawingRef.current.isDrawing && lineDrawingRef.current.line) {
        lineDrawingRef.current.line.set({ x2: pointer.x, y2: pointer.y });
        canvas.renderAll();
      }

      // Handle shape drawing
      if (shapeDrawingRef.current.isDrawing && shapeDrawingRef.current.shape) {
        const startX = shapeDrawingRef.current.startX;
        const startY = shapeDrawingRef.current.startY;
        const width = Math.abs(pointer.x - startX);
        const height = Math.abs(pointer.y - startY);
        
        const shape = shapeDrawingRef.current.shape;
        
        if (shape instanceof fabric.Rect || shape instanceof fabric.Triangle) {
          shape.set({
            left: Math.min(startX, pointer.x),
            top: Math.min(startY, pointer.y),
            width: width,
            height: height,
          });
        } else if (shape instanceof fabric.Circle) {
          const radius = Math.sqrt(width * width + height * height) / 2;
          shape.set({
            left: startX,
            top: startY,
            radius: radius,
            originX: 'center',
            originY: 'center',
          });
        }
        
        canvas.renderAll();
      }
    };

    const handleMouseUp = () => {
      // Reset mouse down position
      mouseDownPositionRef.current = null;
      
      // Handle line drawing end
      if (lineDrawingRef.current.isDrawing) {
        if (lineDrawingRef.current.line) {
          // Always create objects as selectable
          lineDrawingRef.current.line.set({ 
            selectable: true,
            evented: true,
            hasControls: true,
            hasBorders: true,
            borderColor: 'rgba(0, 0, 0, 0.6)',
            cornerColor: 'rgba(0, 0, 0, 0.9)',
            cornerStyle: 'circle',
            cornerSize: 12,
            transparentCorners: false,
            borderScaleFactor: 2,
            padding: 8,
            borderDashArray: [5, 5],
          });
          
          // Select the newly created object
          canvas.setActiveObject(lineDrawingRef.current.line);
          selectionCountRef.current = 1;
          console.log('[SELECTION] Count: 0 → 1 (line created and selected)');
          canvas.renderAll();
        }
        lineDrawingRef.current.isDrawing = false;
        lineDrawingRef.current.line = null;
      }

      // Handle shape drawing end
      if (shapeDrawingRef.current.isDrawing) {
        if (shapeDrawingRef.current.shape) {
          // Always create objects as selectable
          shapeDrawingRef.current.shape.set({ 
            selectable: true,
            evented: true,
            hasControls: true,
            hasBorders: true,
            borderColor: 'rgba(0, 0, 0, 0.6)',
            cornerColor: 'rgba(0, 0, 0, 0.9)',
            cornerStyle: 'circle',
            cornerSize: 12,
            transparentCorners: false,
            borderScaleFactor: 2,
            padding: 8,
            borderDashArray: [5, 5],
          });
          
          // Select the newly created object
          canvas.setActiveObject(shapeDrawingRef.current.shape);
          selectionCountRef.current = 1;
          console.log('[SELECTION] Count: 0 → 1 (shape created and selected)');
          canvas.renderAll();
        }
        shapeDrawingRef.current.isDrawing = false;
        shapeDrawingRef.current.shape = null;
      }

      // Trigger auto-save after mouse up (with 500ms debounce)
      autoSaveCanvas();
    };

    canvas.on('mouse:down', handleMouseDown);
    canvas.on('mouse:move', handleMouseMove);
    canvas.on('mouse:up', handleMouseUp);

    return () => {
      canvas.off('mouse:down', handleMouseDown);
      canvas.off('mouse:move', handleMouseMove);
      canvas.off('mouse:up', handleMouseUp);
    };
  }, [drawingState.tool, drawingState.color, drawingState.brushSize, shapeFillMode, autoSaveCanvas]);

  // Add text
  const addText = (x: number, y: number) => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const text = new fabric.IText('Text', {
      left: x,
      top: y,
      fontSize: 24,
      fontFamily: 'Arial',
      fill: drawingState.color,
      // Always create as selectable
      selectable: true,
      evented: true,
      borderColor: 'rgba(0, 0, 0, 0.6)',
      cornerColor: 'rgba(0, 0, 0, 0.9)',
      cornerStyle: 'circle',
      cornerSize: 12,
      transparentCorners: false,
      borderScaleFactor: 2,
      padding: 8,
      borderDashArray: [5, 5],
    });

    canvas.add(text);
    
    // Select the text and enter editing mode
    canvas.setActiveObject(text);
    selectionCountRef.current = 1;
    console.log('[SELECTION] Count: 0 → 1 (text created and selected)');
    text.enterEditing();
    
    canvas.renderAll();
    
    // Trigger auto-save
    autoSaveCanvas();
  };

  // Add shape
  // Add image from file
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const imgUrl = event.target?.result as string;
      addImage(imgUrl);
    };
    reader.readAsDataURL(file);
  };

  const addImage = async (url: string) => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    try {
      const img = await fabric.FabricImage.fromURL(url, { crossOrigin: 'anonymous' });
      
      const scale = Math.min(
        canvasState.width / (img.width || 1) * 0.5,
        canvasState.height / (img.height || 1) * 0.5
      );

      img.set({
        left: canvasState.width / 2,
        top: canvasState.height / 2,
        originX: 'center',
        originY: 'center',
        scaleX: scale,
        scaleY: scale,
        // Always create as selectable
        selectable: true,
        evented: true,
        borderColor: 'rgba(0, 0, 0, 0.6)',
        cornerColor: 'rgba(0, 0, 0, 0.9)',
        cornerStyle: 'circle',
        cornerSize: 12,
        transparentCorners: false,
        borderScaleFactor: 2,
        padding: 8,
        borderDashArray: [5, 5],
      });

      canvas.add(img);
      
      // Select the image
      canvas.setActiveObject(img);
      selectionCountRef.current = 1;
      console.log('[SELECTION] Count: 0 → 1 (image added and selected)');
      
      canvas.renderAll();
      
      // Trigger auto-save
      autoSaveCanvas();
    } catch (error) {
      console.error('[IMAGE] Error loading image:', error);
    }
  };

  // Save current canvas to frame
  // Handle zoom
  const handleZoomChange = (value: number) => {
    setZoom(value);
    // Zoom is handled by CSS transform on the canvas container
    // No need to modify Fabric canvas zoom
  };

  // Handle pan
  const handlePanChange = (value: number) => {
    setPanValue(value);
    
    // Update canvas container position instead of viewport transform
    setCanvasPosition(prev => {
      if (panAxis === 'x') {
        return { ...prev, x: value };
      } else {
        return { ...prev, y: value };
      }
    });
  };

  const tools = [
    { type: 'brush', icon: <Pencil className="w-4 h-4" />, label: 'Brush' },
    { type: 'eraser', icon: <Eraser className="w-4 h-4" />, label: 'Eraser' },
    { type: 'line', icon: <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="19" x2="19" y2="5"/></svg>, label: 'Line' },
    { type: 'rectangle', icon: <Square className="w-4 h-4" />, label: 'Rectangle' },
    { type: 'circle', icon: <Circle className="w-4 h-4" />, label: 'Circle' },
    { type: 'triangle', icon: <Triangle className="w-4 h-4" />, label: 'Triangle' },
    { type: 'text', icon: <Type className="w-4 h-4" />, label: 'Text' },
  ];

  const needsColor = !['eraser'].includes(drawingState.tool);
  const needsBrushSize = ['brush', 'eraser'].includes(drawingState.tool);
  const needsStrokeWidth = ['line', 'rectangle', 'circle', 'triangle'].includes(drawingState.tool);

  return (
    <div ref={containerRef} className="relative w-full h-full flex items-center justify-center bg-muted overflow-hidden">
      {/* Canvas Container with Zoom and Position */}
      <div 
        className="relative flex items-center justify-center"
        style={{ 
          transform: `translate(${canvasPosition.x}px, ${canvasPosition.y}px) scale(${zoom / 100})`,
          transformOrigin: 'center center',
          transition: isDraggingCanvas ? 'none' : 'transform 0.2s ease-out'
        }}
      >
        {/* Main Fabric Canvas */}
        <canvas 
          ref={canvasRef} 
          className={cn(
            "border border-border shadow-lg",
            drawingState.tool === 'eraser' && 'cursor-eraser',
            drawingState.tool === 'brush' && 'cursor-brush'
          )}
          style={{ zIndex: 2 }}
        />
      </div>

      {/* Vertical Toolbar - Left */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-card/95 backdrop-blur-sm border rounded-xl shadow-lg p-2 flex flex-col gap-1">
        {tools.map((tool) => (
          <Button
            key={tool.type}
            variant={drawingState.tool === tool.type ? 'default' : 'ghost'}
            size="icon"
            onClick={() => setDrawingState({ ...drawingState, tool: tool.type as any })}
            title={tool.label}
            className={cn(
              'h-8 w-8 rounded-lg transition-all duration-200',
              drawingState.tool === tool.type
                ? 'bg-foreground text-background shadow-md scale-105'
                : 'hover:bg-muted hover:scale-105'
            )}
          >
            {tool.icon}
          </Button>
        ))}

        {/* Image Upload */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => fileInputRef.current?.click()}
          title="Add Image"
          className="h-8 w-8 rounded-lg hover:bg-muted hover:scale-105 transition-all duration-200"
        >
          <ImageIcon className="w-4 h-4" />
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          className="hidden"
        />

        {/* Color Picker */}
        {needsColor && (
          <div className="mt-1 pt-1 border-t">
            <Input
              type="color"
              value={drawingState.color}
              onChange={(e) => setDrawingState({ ...drawingState, color: e.target.value })}
              className="h-8 w-8 cursor-pointer p-0.5 border-2 rounded-lg hover:scale-105 transition-transform duration-200"
              title="Color"
            />
          </div>
        )}
      </div>

      {/* Top Controls - 2 Rows */}
      {needsBrushSize && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 bg-card/95 backdrop-blur-sm border rounded-lg shadow-lg px-4 py-2 flex flex-col gap-2 min-w-[320px]">
          {/* Size Row */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground whitespace-nowrap w-12">Size</span>
            <input
              type="range"
              min="1"
              max="50"
              value={drawingState.brushSize}
              onChange={(e) => setDrawingState({ ...drawingState, brushSize: Number(e.target.value) })}
              className="flex-1 accent-foreground"
            />
            <span className="text-xs font-medium w-6 text-right">{drawingState.brushSize}</span>
          </div>
          
          {/* Opacity Row */}
          {drawingState.tool === 'brush' && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground whitespace-nowrap w-12">Opacity</span>
              <input
                type="range"
                min="10"
                max="100"
                value={drawingState.opacity * 100}
                onChange={(e) => setDrawingState({ ...drawingState, opacity: Number(e.target.value) / 100 })}
                className="flex-1 accent-foreground"
              />
              <span className="text-xs font-medium w-6 text-right">{Math.round(drawingState.opacity * 100)}%</span>
            </div>
          )}
        </div>
      )}

      {/* Shape Fill/Stroke Controls */}
      {needsStrokeWidth && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 bg-card/95 backdrop-blur-sm border rounded-lg shadow-lg px-4 py-2 flex flex-col gap-2 min-w-[320px]">
          {/* Fill/Stroke Mode Row */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground whitespace-nowrap w-12">Mode</span>
            <div className="flex gap-1 flex-1">
              <Button
                variant={shapeFillMode === 'fill' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setShapeFillMode('fill')}
                className="flex-1 h-7 text-xs"
              >
                Fill
              </Button>
              <Button
                variant={shapeFillMode === 'stroke' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setShapeFillMode('stroke')}
                className="flex-1 h-7 text-xs"
              >
                Stroke
              </Button>
            </div>
          </div>
          
          {/* Stroke Width Row */}
          {shapeFillMode === 'stroke' && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground whitespace-nowrap w-12">Width</span>
              <input
                type="range"
                min="1"
                max="20"
                value={drawingState.brushSize}
                onChange={(e) => setDrawingState({ ...drawingState, brushSize: Number(e.target.value) })}
                className="flex-1 accent-foreground"
              />
              <span className="text-xs font-medium w-6 text-right">{drawingState.brushSize}</span>
            </div>
          )}
        </div>
      )}

      {/* Delete and Lock Buttons - Right (only show when object selected) */}
      {hasSelection && (
        <div className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-card/95 backdrop-blur-sm border rounded-xl shadow-lg p-2 flex flex-col gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleLockSelected}
            className="h-10 w-10 rounded-lg text-foreground hover:bg-muted hover:scale-105 transition-all duration-200"
            title={isSelectedObjectLocked ? "Unlock Selected (Ctrl+L)" : "Lock Selected (Ctrl+L)"}
          >
            {isSelectedObjectLocked ? (
              <Lock className="w-5 h-5" />
            ) : (
              <Unlock className="w-5 h-5" />
            )}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={deleteSelected}
            className="h-10 w-10 rounded-lg text-foreground hover:bg-muted hover:scale-105 transition-all duration-200"
            title="Delete Selected (Delete)"
          >
            <Trash2 className="w-5 h-5" />
          </Button>
        </div>
      )}

      {/* Pan Control - Above Zoom */}
      <div className="absolute bottom-20 right-4 z-30 bg-card/95 backdrop-blur-sm border rounded-xl shadow-lg px-4 py-2 flex items-center gap-3 min-w-[200px]">
        <Select value={panAxis} onValueChange={(value: 'x' | 'y') => setPanAxis(value)}>
          <SelectTrigger className="h-7 text-xs w-16">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="x">X</SelectItem>
            <SelectItem value="y">Y</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground whitespace-nowrap w-10 text-right">{panValue}</span>
        <input
          type="range"
          min="-500"
          max="500"
          value={panValue}
          onChange={(e) => handlePanChange(Number(e.target.value))}
          className="flex-1 accent-foreground"
        />
      </div>

      {/* Zoom Slider - Bottom Right */}
      <div className="absolute bottom-4 right-4 z-30 bg-card/95 backdrop-blur-sm border rounded-xl shadow-lg px-4 py-2 flex items-center gap-3 min-w-[200px]">
        <span className="text-xs text-muted-foreground whitespace-nowrap">{zoom}%</span>
        <input
          type="range"
          min="10"
          max="200"
          value={zoom}
          onChange={(e) => handleZoomChange(Number(e.target.value))}
          className="flex-1 accent-foreground"
        />
      </div>

      {/* Canvas Info & Onion Skin Toggle - Bottom Left */}
      <div className="absolute bottom-4 left-4 z-30 flex gap-2">
        <div className="bg-card/95 backdrop-blur-sm border rounded-lg shadow-lg px-3 py-1.5 text-xs text-muted-foreground">
          Canvas: {canvasState.width} × {canvasState.height}px
        </div>
        <Button
          variant={showOnionSkin ? 'default' : 'outline'}
          size="sm"
          onClick={() => setShowOnionSkin(!showOnionSkin)}
          className="h-auto py-1.5 text-xs rounded-lg"
          title="Show previous frames as ghost images to help with animation"
        >
          <svg className="w-3 h-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" opacity="0.3"/>
            <circle cx="12" cy="12" r="6" opacity="0.6"/>
            <circle cx="12" cy="12" r="2"/>
          </svg>
          Onion Skin
        </Button>
      </div>
    </div>
  );
};

export default FabricDrawingCanvas;
