import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useSpriteEditor } from '../context/SpriteEditorContext';

const AnimationSettings: React.FC = () => {
  const { animationSettings, setAnimationSettings, canvasState, setCanvasSize } = useSpriteEditor();

  return (
    <div>
      <h3 className="font-semibold text-sm mb-3">Animation Settings</h3>
      
      <div className="space-y-3">
        <div>
          <Label htmlFor="asset-name" className="text-xs">Name</Label>
          <Input
            id="asset-name"
            value={animationSettings.name}
            onChange={(e) => setAnimationSettings({ ...animationSettings, name: e.target.value })}
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="fps" className="text-xs">FPS</Label>
          <Input
            id="fps"
            type="number"
            min={1}
            max={60}
            value={animationSettings.fps}
            onChange={(e) => setAnimationSettings({ ...animationSettings, fps: Number(e.target.value) })}
            className="mt-1"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Frame Dimensions</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="frame-width" className="text-xs text-muted-foreground">Width</Label>
              <Input
                id="frame-width"
                type="number"
                min={64}
                max={2048}
                step={64}
                value={canvasState.width}
                onChange={(e) => setCanvasSize(Number(e.target.value), canvasState.height)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="frame-height" className="text-xs text-muted-foreground">Height</Label>
              <Input
                id="frame-height"
                type="number"
                min={64}
                max={2048}
                step={64}
                value={canvasState.height}
                onChange={(e) => setCanvasSize(canvasState.width, Number(e.target.value))}
                className="mt-1"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnimationSettings;
