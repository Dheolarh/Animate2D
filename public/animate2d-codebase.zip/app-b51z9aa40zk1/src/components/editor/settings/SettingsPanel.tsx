import React, { useState } from 'react';
import { Save, X, Play, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import AnimationSettings from './AnimationSettings';
import CanvasSettings from './CanvasSettings';
import AnimationPreview from '../preview/AnimationPreview';

interface SettingsPanelProps {
  onSave: () => void;
  onClose: () => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ onSave, onClose }) => {
  const [showPreview, setShowPreview] = useState(false);
  const [transparentBackground, setTransparentBackground] = useState(false);

  const handleSaveAsAnimClip = () => {
    // Save as .animclip to main editor library
    onSave();
  };

  const handleExportAsMP4 = () => {
    // Export as .mp4 video file (download)
    // TODO: Implement MP4 export with canvas dimensions
    console.log('Export as MP4 with transparent:', transparentBackground);
  };

  return (
    <div className="w-64 border-r bg-card p-4 space-y-4 overflow-y-auto flex-shrink-0">
      <AnimationSettings />
      
      <Separator />
      
      <CanvasSettings />
      
      <Separator />
      
      {/* Export Options */}
      <div className="space-y-3">
        <h3 className="text-sm font-medium">Export Options</h3>
        <div className="flex items-center justify-between">
          <Label htmlFor="transparent-bg" className="text-xs">
            Transparent Background
          </Label>
          <Switch
            id="transparent-bg"
            checked={transparentBackground}
            onCheckedChange={setTransparentBackground}
          />
        </div>
      </div>
      
      <Separator />
      
      {/* Action Buttons */}
      <div className="space-y-2">
        <Button onClick={() => setShowPreview(true)} variant="outline" className="w-full">
          <Play className="w-4 h-4 mr-2" />
          Preview
        </Button>
        
        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="flex-1">
                <Save className="w-4 h-4 mr-2" />
                Save
                <ChevronDown className="w-3 h-3 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuItem onClick={handleSaveAsAnimClip}>
                <div className="flex flex-col">
                  <span className="font-medium">Save as .animclip</span>
                  <span className="text-xs text-muted-foreground">Compressed format for editor library</span>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleExportAsMP4}>
                <div className="flex flex-col">
                  <span className="font-medium">Export as .mp4</span>
                  <span className="text-xs text-muted-foreground">Standard video file (download)</span>
                </div>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button onClick={onClose} variant="outline" size="icon">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <AnimationPreview open={showPreview} onOpenChange={setShowPreview} />
    </div>
  );
};

export default SettingsPanel;
