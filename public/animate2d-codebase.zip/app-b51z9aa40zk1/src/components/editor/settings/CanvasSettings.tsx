import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useSpriteEditor } from '../context/SpriteEditorContext';

const CanvasSettings: React.FC = () => {
  const { canvasState, setCanvasState } = useSpriteEditor();

  const handleBackgroundColorChange = (color: string) => {
    setCanvasState({ ...canvasState, backgroundColor: color });
  };

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-medium">Canvas Settings</h3>
      
      <div className="space-y-2">
        <Label htmlFor="bg-color" className="text-xs">
          Background Color
        </Label>
        <div className="flex gap-2 items-center">
          <Input
            id="bg-color"
            type="color"
            value={canvasState.backgroundColor || '#ffffff'}
            onChange={(e) => handleBackgroundColorChange(e.target.value)}
            className="w-12 h-8 p-1 cursor-pointer"
          />
          <Input
            type="text"
            value={canvasState.backgroundColor || '#ffffff'}
            onChange={(e) => handleBackgroundColorChange(e.target.value)}
            className="flex-1 h-8 text-xs"
            placeholder="#ffffff"
          />
        </div>
      </div>
    </div>
  );
};

export default CanvasSettings;
