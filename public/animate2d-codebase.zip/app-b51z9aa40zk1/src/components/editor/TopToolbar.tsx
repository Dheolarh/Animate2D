import React from 'react';
import { ArrowLeft, Play, Pause, Square, Download, Pencil, MousePointer2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import type { EditorMode } from '@/types/animation';
import { useNavigate } from 'react-router-dom';

interface TopToolbarProps {
  mode: EditorMode;
  onModeChange: (mode: EditorMode) => void;
  projectName: string;
  isPlaying: boolean;
  onPlayPause: () => void;
  onStop: () => void;
  saveStatus?: 'saved' | 'saving' | 'unsaved';
}

const TopToolbar: React.FC<TopToolbarProps> = ({
  mode,
  onModeChange,
  projectName,
  isPlaying,
  onPlayPause,
  onStop,
  saveStatus = 'saved'
}) => {
  const navigate = useNavigate();

  return (
    <div className="h-16 border-b bg-gradient-to-b from-card to-card/95 backdrop-blur-sm flex items-center px-6 gap-4 shadow-sm">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => navigate('/projects')}
        title="Back to Projects"
        className="rounded-full hover:bg-accent/80 transition-all duration-200 hover:scale-105"
      >
        <ArrowLeft className="w-4 h-4" />
      </Button>

      <div className="font-semibold text-sm truncate max-w-xs px-3 py-1.5 rounded-md bg-muted/50">
        {projectName}
      </div>

      <Separator orientation="vertical" className="h-8" />

      <ToggleGroup 
        type="single" 
        value={mode} 
        onValueChange={(value) => value && onModeChange(value as EditorMode)}
        className="bg-muted/30 rounded-lg p-1 shadow-inner"
      >
        <ToggleGroupItem 
          value="sprite" 
          aria-label="Sprite Editor"
          className="rounded-md data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:shadow-md transition-all duration-200 hover:scale-105"
        >
          <Pencil className="w-4 h-4 mr-2" />
          Sprite Editor
        </ToggleGroupItem>
        <ToggleGroupItem 
          value="scene" 
          aria-label="Scene Mode"
          className="rounded-md data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:shadow-md transition-all duration-200 hover:scale-105"
        >
          <MousePointer2 className="w-4 h-4 mr-2" />
          Scene
        </ToggleGroupItem>
        <ToggleGroupItem 
          value="preview" 
          aria-label="Preview Mode"
          className="rounded-md data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:shadow-md transition-all duration-200 hover:scale-105"
        >
          <Play className="w-4 h-4 mr-2" />
          Preview
        </ToggleGroupItem>
        <ToggleGroupItem 
          value="export" 
          aria-label="Export Mode"
          className="rounded-md data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:shadow-md transition-all duration-200 hover:scale-105"
        >
          <Download className="w-4 h-4 mr-2" />
          Export
        </ToggleGroupItem>
      </ToggleGroup>

      <Separator orientation="vertical" className="h-8" />

      <div className="flex items-center gap-2 bg-muted/30 rounded-lg p-1 shadow-inner">
        <Button
          variant="ghost"
          size="icon"
          onClick={onPlayPause}
          title={isPlaying ? 'Pause' : 'Play'}
          className="rounded-md hover:bg-accent/80 transition-all duration-200 hover:scale-105"
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={onStop}
          title="Stop"
          className="rounded-md hover:bg-accent/80 transition-all duration-200 hover:scale-105"
        >
          <Square className="w-4 h-4" />
        </Button>
      </div>

      {saveStatus === 'saved' && (
        <div className="ml-auto text-xs text-muted-foreground font-mono px-3 py-1.5 rounded-md bg-muted/50">
          All changes saved
        </div>
      )}
      {saveStatus === 'saving' && (
        <div className="ml-auto text-xs text-muted-foreground font-mono px-3 py-1.5 rounded-md bg-muted/50 animate-pulse">
          Auto-saving...
        </div>
      )}
      {saveStatus === 'unsaved' && (
        <div className="ml-auto text-xs text-orange-500 font-mono px-3 py-1.5 rounded-md bg-muted/50">
          Unsaved changes
        </div>
      )}
    </div>
  );
};

export default TopToolbar;
