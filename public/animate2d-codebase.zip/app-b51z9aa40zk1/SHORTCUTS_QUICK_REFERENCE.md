# Keyboard & Mouse Shortcuts - Quick Reference

## Undo/Redo
- **Ctrl+Z / Cmd+Z** - Undo
- **Ctrl+Y / Cmd+Y** - Redo
- **Ctrl+Shift+Z / Cmd+Shift+Z** - Redo (alt)

## Tools
- **B** - Brush
- **E** - Eraser  
- **R** - Rectangle
- **C** - Circle
- **T** - Text
- **L** - Line
- **I** - Image

## Object Control
- **Delete / Backspace** - Delete selected object
- **Escape** - Deselect
- **Arrow Keys** - Move 1px
- **Shift + Arrows** - Move 10px

## Mouse Controls
- **Scroll Wheel** - Zoom in/out
- **Right-Click + Drag** - Pan canvas

## Tips
- Shortcuts work when canvas is focused
- Won't trigger when typing in input fields
- Case-insensitive (works with Caps Lock)
- Zoom centers on mouse cursor
- Right-click panning disables context menu
