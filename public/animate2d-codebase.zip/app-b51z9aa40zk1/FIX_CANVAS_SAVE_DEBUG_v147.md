# Add Debugging for Canvas Save/Load - v147

## Issue

User reported that localStorage saving was not working correctly:
- Drawing a shape and then brush strokes: only one type saves
- Drawing only brush strokes: saves correctly
- Drawing only shapes: saves correctly
- When two different object types appear: only one type saves
- Images not saved at all
- Text not tested

## Investigation

The canvas save/load code appeared correct:
- Using `canvas.toJSON()` to serialize all objects
- Using `canvas.loadFromJSON()` to deserialize
- Auto-save triggered on object:added, object:modified, object:removed, path:created

However, there was no debugging to verify what was actually being saved and loaded.

## Solution

Add comprehensive debugging to the save and load functions to track:
1. How many objects are being saved
2. What types of objects are being saved
3. The size of the JSON data
4. How many objects are in the saved JSON
5. How many objects are being loaded
6. What types of objects are being loaded

This will help identify where the issue is occurring.

## Implementation

### 1. Add Debugging to Auto-Save

```typescript
const autoSaveCanvas = useCallback(() => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  // ... debounce logic ...

  try {
    // Get all objects for debugging
    const allObjects = canvas.getObjects();
    console.log('[AUTO-SAVE] Saving canvas with', allObjects.length, 'objects');
    console.log('[AUTO-SAVE] Object types:', allObjects.map(obj => obj.type));
    
    // Save canvas - toJSON() includes all objects and properties
    const canvasData = canvas.toJSON();
    const canvasJSON = JSON.stringify(canvasData);
    
    console.log('[AUTO-SAVE] Canvas JSON length:', canvasJSON.length);
    console.log('[AUTO-SAVE] Objects in JSON:', canvasData.objects?.length || 0);
    
    saveCanvasVersion(
      canvasState.width,
      canvasState.height,
      canvasState.backgroundColor || '#ffffff',
      0,
      canvasJSON
    );
    
    setSaveStatus('saved');
    console.log('[AUTO-SAVE] Canvas saved successfully');
  } catch (error) {
    console.error('[AUTO-SAVE] Failed to save:', error);
    setSaveStatus('unsaved');
  }
}, [/* ... */]);
```

### 2. Add Debugging to Load Function

```typescript
const loadCanvasFromVersion = useCallback((versionData: string) => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  try {
    const parsedData = JSON.parse(versionData);
    console.log('[VERSION] Loading canvas with', parsedData.objects?.length || 0, 'objects');
    console.log('[VERSION] Object types:', parsedData.objects?.map((obj: any) => obj.type));
    
    canvas.loadFromJSON(parsedData, () => {
      const loadedObjects = canvas.getObjects();
      console.log('[VERSION] Canvas loaded with', loadedObjects.length, 'objects');
      console.log('[VERSION] Loaded object types:', loadedObjects.map(obj => obj.type));
      canvas.renderAll();
      console.log('[VERSION] Canvas loaded from version');
    });
  } catch (error) {
    console.error('[VERSION] Failed to load canvas:', error);
  }
}, []);
```

## Debugging Output

### When Saving

```
[AUTO-SAVE] Saving canvas with 5 objects
[AUTO-SAVE] Object types: ['path', 'rect', 'circle', 'i-text', 'image']
[AUTO-SAVE] Canvas JSON length: 12345
[AUTO-SAVE] Objects in JSON: 5
[AUTO-SAVE] Canvas saved successfully
```

### When Loading

```
[VERSION] Loading canvas with 5 objects
[VERSION] Object types: ['path', 'rect', 'circle', 'i-text', 'image']
[VERSION] Canvas loaded with 5 objects
[VERSION] Loaded object types: ['path', 'rect', 'circle', 'i-text', 'image']
[VERSION] Canvas loaded from version
```

## How to Use

### Testing the Issue

1. Open browser console (F12)
2. Draw a rectangle
3. Check console: `[AUTO-SAVE] Saving canvas with 1 objects`
4. Check console: `[AUTO-SAVE] Object types: ['rect']`
5. Draw a brush stroke
6. Check console: `[AUTO-SAVE] Saving canvas with 2 objects`
7. Check console: `[AUTO-SAVE] Object types: ['rect', 'path']`
8. Refresh page
9. Check console: `[VERSION] Loading canvas with X objects`
10. Check console: `[VERSION] Loaded object types: [...]`

### Identifying the Problem

**If objects are saved but not loaded**:
- Save shows: `Saving canvas with 5 objects`
- Load shows: `Loading canvas with 5 objects`
- But: `Canvas loaded with 3 objects`
- **Problem**: loadFromJSON is not loading all objects

**If objects are not saved**:
- Save shows: `Saving canvas with 5 objects`
- But: `Objects in JSON: 3`
- **Problem**: toJSON is not serializing all objects

**If wrong objects are saved**:
- Canvas has: rectangle, circle, brush stroke
- Save shows: `Object types: ['rect', 'circle']`
- **Problem**: Some objects are not being included in getObjects()

## Expected Behavior

### All Object Types Should Save

- **Brush strokes** (path): ✅ Should save
- **Shapes** (rect, circle, triangle): ✅ Should save
- **Lines** (line): ✅ Should save
- **Text** (i-text): ✅ Should save
- **Images** (image): ✅ Should save

### Mixed Objects Should Save

- Rectangle + brush stroke: ✅ Both should save
- Circle + text: ✅ Both should save
- Image + shapes: ✅ All should save
- Any combination: ✅ All should save

## Next Steps

After adding this debugging:

1. **Reproduce the issue** with console open
2. **Check the logs** to see where objects are lost:
   - Are they saved? (check AUTO-SAVE logs)
   - Are they in the JSON? (check Objects in JSON count)
   - Are they loaded? (check VERSION logs)
3. **Identify the root cause**:
   - If saved but not loaded: issue with loadFromJSON
   - If not saved: issue with toJSON or getObjects
   - If wrong types: issue with object creation or filtering
4. **Fix the specific issue** based on the logs

## Possible Root Causes

### 1. Object Filtering

Some objects might be filtered out:
```typescript
// Check if there's filtering
canvas.getObjects().filter(obj => /* some condition */)
```

### 2. Async Issues

Objects might be added asynchronously and not saved yet:
```typescript
// Images load asynchronously
fabric.FabricImage.fromURL(url, (img) => {
  canvas.add(img); // Might not trigger auto-save
});
```

### 3. Custom Properties

Custom properties might not be serialized:
```typescript
// Need to specify custom properties
canvas.toJSON(['customProp1', 'customProp2'])
```

### 4. localStorage Limits

localStorage might be full (5-10MB limit):
```typescript
// Check if quota exceeded
try {
  localStorage.setItem(key, value);
} catch (e) {
  if (e.name === 'QuotaExceededError') {
    console.error('localStorage quota exceeded');
  }
}
```

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Added debugging logs to autoSaveCanvas function
  - Added debugging logs to loadCanvasFromVersion function
  - Logs object counts and types for save and load operations

## Version

- v147: Add debugging for canvas save/load
- Comprehensive logging for save operations
- Comprehensive logging for load operations
- Helps identify where objects are lost
- Foundation for fixing the save issue ✅

## Related

- Canvas persistence
- localStorage
- Object serialization
- Debugging
- Issue investigation
