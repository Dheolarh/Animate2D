# Draggable Frame and Pan UI Update - v132

## Overview

Made the canvas frame draggable by adding a border rectangle that can be moved around the viewport, and updated the pan control UI layout to be more compact and intuitive.

## Features

### 1. Draggable Frame Border

Added a transparent rectangle border around the canvas that can be selected and dragged.

#### Properties
- **Position**: Matches canvas dimensions (0, 0 to width, height)
- **Appearance**: Transparent fill with black 2px stroke
- **Behavior**: 
  - ✅ Selectable and draggable
  - ✅ Has corner controls for easy grabbing
  - ✅ Locked rotation (can't rotate)
  - ✅ Locked scaling (can't resize)
  - ✅ Not erasable (protected from eraser tool)
  - ✅ Always at the back (behind all other objects)

#### How to Use
1. Click on the frame border (black outline)
2. Drag it anywhere in the viewport
3. Use corner controls to grab and position
4. Frame moves independently of canvas content

#### Use Cases
- **Viewport Positioning**: Move frame to different areas
- **Composition**: Position frame for better view
- **Animation**: Create camera movement by repositioning frame
- **Workflow**: Drag frame to comfortable working position

### 2. Updated Pan Control UI

Reorganized the pan control layout for better usability.

#### Old Layout
```
┌─────────────────────┐
│ Pan: [X▼]           │
│ 0    ━━━━━━━━━━━━━  │
└─────────────────────┘
```

#### New Layout
```
┌─────────────────────┐
│ [X▼]  0  ━━━━━━━━━  │
└─────────────────────┘
```

#### Changes
- ✅ Removed "Pan:" label text
- ✅ Moved dropdown to the front (leftmost)
- ✅ Number value in the middle
- ✅ Slider on the right
- ✅ Single row layout (more compact)
- ✅ Better visual hierarchy

#### Layout Order
1. **Dropdown** (X/Y axis selector) - 16px width
2. **Number** (current pan value) - 10px width, right-aligned
3. **Slider** (range input) - flexible width

## Implementation Details

### Frame Border Creation

```typescript
// Add draggable frame border
const frameBorder = new fabric.Rect({
  left: 0,
  top: 0,
  width: canvasState.width,
  height: canvasState.height,
  fill: 'transparent',
  stroke: '#000000',
  strokeWidth: 2,
  selectable: true,
  evented: true,
  hasControls: true,
  hasBorders: true,
  lockRotation: true,
  lockScalingX: true,
  lockScalingY: true,
  erasable: false,
});

(frameBorder as any).name = 'frameBorder';
canvas.add(frameBorder);
canvas.sendObjectToBack(frameBorder);
```

### Key Properties Explained

- `fill: 'transparent'` - See through the frame
- `stroke: '#000000'` - Black border for visibility
- `strokeWidth: 2` - Visible but not too thick
- `selectable: true` - Can be clicked and selected
- `lockRotation: true` - Prevents rotation
- `lockScalingX/Y: true` - Prevents resizing
- `erasable: false` - Protected from eraser tool
- `sendObjectToBack()` - Always behind other objects

### Pan Control UI Update

```tsx
{/* Pan Control - Above Zoom */}
<div className="absolute bottom-20 right-4 z-30 bg-card/95 backdrop-blur-sm border rounded-xl shadow-lg px-4 py-2 flex items-center gap-3 min-w-[200px]">
  <Select value={panAxis} onValueChange={(value: 'x' | 'y') => setPanAxis(value)}>
    <SelectTrigger className="h-7 text-xs w-16">
      <SelectValue />
    </SelectTrigger>
    <SelectContent>
      <SelectItem value="x">X</SelectItem>
      <SelectItem value="y">Y</SelectItem>
    </SelectContent>
  </Select>
  <span className="text-xs text-muted-foreground whitespace-nowrap w-10 text-right">{panValue}</span>
  <input
    type="range"
    min="-500"
    max="500"
    value={panValue}
    onChange={(e) => handlePanChange(Number(e.target.value))}
    className="flex-1 accent-foreground"
  />
</div>
```

### Layout Changes

- Changed from `flex-col gap-2` to `flex items-center gap-3`
- Removed nested divs
- Single row with all controls inline
- Number span has fixed width `w-10` and `text-right` alignment

## Testing

### Test 1: Frame Dragging
1. Click on the black frame border
2. ✅ Frame should be selected (shows corner controls)
3. Drag the frame
4. ✅ Frame should move around viewport
5. Try to rotate
6. ✅ Should not rotate (locked)
7. Try to resize
8. ✅ Should not resize (locked)

### Test 2: Frame Behind Objects
1. Draw some objects on canvas
2. Select and drag the frame
3. ✅ Frame should stay behind all objects
4. Objects should not move with frame
5. ✅ Frame moves independently

### Test 3: Frame with Eraser
1. Select eraser tool
2. Try to erase the frame border
3. ✅ Frame should not be erased
4. Other objects should erase normally

### Test 4: Pan Control UI
1. Look at pan control
2. ✅ Should see: [X▼] 0 ━━━━━━
3. ✅ No "Pan:" label
4. ✅ Dropdown on left
5. ✅ Number in middle
6. ✅ Slider on right
7. ✅ All in one row

### Test 5: Combined Features
1. Drag frame to new position
2. Use pan slider to adjust viewport
3. ✅ Both should work independently
4. Zoom in/out
5. ✅ Frame should zoom with canvas
6. Right-click pan
7. ✅ All features work together

## Benefits

### Draggable Frame
✅ **Flexible Positioning**: Move frame anywhere in viewport
✅ **Visual Feedback**: See frame border clearly
✅ **Protected**: Can't be accidentally modified or erased
✅ **Independent**: Moves separately from canvas content
✅ **Professional**: Matches animation software workflow

### Updated Pan UI
✅ **More Compact**: Single row saves vertical space
✅ **Better Flow**: Left-to-right reading order
✅ **Less Clutter**: Removed unnecessary label
✅ **Cleaner Look**: More professional appearance
✅ **Easier to Use**: All controls visible at once

## Use Cases

### Animation Workflow
1. Draw animation frame content
2. Drag frame border to position viewport
3. Use pan slider for fine adjustments
4. Create camera movement effects

### Detail Work
1. Zoom in on specific area
2. Drag frame to comfortable position
3. Work on details
4. Move frame as needed

### Composition
1. Position frame for best view
2. Arrange objects within frame
3. Adjust frame position for different angles
4. Export with frame in desired position

## Limitations

- Frame border is always rectangular (matches canvas)
- Frame can't be resized (locked to canvas dimensions)
- Frame position doesn't affect export (cosmetic only)
- Pan slider doesn't sync with frame drag position

## Future Enhancements

- Snap frame to viewport edges
- Center frame button
- Lock frame position toggle
- Frame position presets
- Sync pan slider with frame position
- Multiple frame sizes/ratios
- Frame color customization

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Added frame border rectangle creation
  - Set frame properties (transparent, draggable, locked)
  - Positioned frame at back of canvas
  - Updated pan control UI layout
  - Removed "Pan:" label
  - Reorganized controls in single row

## Version

- v132: Added draggable frame border and updated pan UI
- Frame is draggable with corner controls
- Pan control is more compact and intuitive
- All features working correctly ✅

## Related

- Fabric.js object layering
- Canvas viewport management
- UI/UX for animation tools
- Frame positioning techniques
