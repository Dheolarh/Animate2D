# Eraser Color Not Updating When Background Changes - Fix

## Problem Description

**Symptom:** When using the eraser tool and then changing the canvas background color, the eraser continues to erase with the old background color instead of the new one.

**Example:**
1. Canvas background is white
2. User draws with brush
3. User switches to eraser (eraser color = white)
4. User changes canvas background to magenta
5. User erases → eraser still uses white instead of magenta
6. Result: White eraser marks visible on magenta background

## Root Cause

The eraser tool is implemented as a brush that draws with the background color. When the background color changes, two things happen:

1. ✅ The canvas background is updated
2. ❌ The eraser brush color is NOT updated

The eraser brush color is only set when:
- The eraser tool is first selected
- The tool changes (switching between tools)

But NOT when:
- The background color changes while the eraser is already active

## The Fix

### Before (Buggy Code)

```typescript
// Update background color when it changes
useEffect(() => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  canvas.backgroundColor = canvasState.backgroundColor || '#ffffff';
  canvas.renderAll();
  // Eraser brush color is NOT updated here!
}, [canvasState.backgroundColor]);
```

### After (Fixed Code)

```typescript
// Update background color when it changes
useEffect(() => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  canvas.backgroundColor = canvasState.backgroundColor || '#ffffff';
  canvas.renderAll();
  
  // CRITICAL FIX: Update eraser color if currently using eraser tool
  if (drawingState.tool === 'eraser' && canvas.freeDrawingBrush) {
    canvas.freeDrawingBrush.color = canvasState.backgroundColor || '#ffffff';
  }
}, [canvasState.backgroundColor, drawingState.tool]);
```

## Key Changes

1. **Check Current Tool:** Added check for `drawingState.tool === 'eraser'`
2. **Update Brush Color:** Directly update `canvas.freeDrawingBrush.color` with new background color
3. **Add Dependency:** Added `drawingState.tool` to dependency array to ensure effect runs when tool changes

## Why This Works

The `freeDrawingBrush` object is a reference to the current brush being used. When we update its `color` property directly, the eraser immediately starts using the new color for subsequent strokes.

### Flow Diagram

```
User changes background color
    ↓
useEffect triggers (canvasState.backgroundColor changed)
    ↓
Update canvas.backgroundColor
    ↓
Check if current tool is 'eraser'
    ↓
If yes: Update canvas.freeDrawingBrush.color
    ↓
Eraser now uses new background color
```

## Helper Function Added

Added a new helper function to the copiables:

```typescript
/**
 * Update eraser color when background color changes.
 * Call this when the background color changes and the eraser tool is active.
 */
export const updateEraserColor = (
  canvas: fabric.Canvas,
  backgroundColor: string
) => {
  if (canvas.freeDrawingBrush) {
    canvas.freeDrawingBrush.color = backgroundColor;
  }
};
```

### Usage

```typescript
// When background color changes
canvas.backgroundColor = newColor;
if (currentTool === 'eraser') {
  updateEraserColor(canvas, newColor);
}
```

## Testing Checklist

- [x] Change background color while using eraser - eraser updates immediately
- [x] Erase after background change - eraser uses new background color
- [x] Switch to eraser after background change - eraser uses current background color
- [x] Change background multiple times - eraser always matches current background
- [x] Switch between brush and eraser - both tools work correctly
- [x] Change background while using brush - brush color unaffected (correct)

## Related Code

### Files Modified

1. **FabricDrawingCanvas.tsx**
   - Updated background color effect to update eraser brush color
   - Added `drawingState.tool` to dependency array

2. **src/copiables/fabricHelpers.ts**
   - Added `updateEraserColor` helper function

3. **src/copiables/index.ts**
   - Exported `updateEraserColor` function

## Best Practice

**Always update tool-specific properties when their dependencies change.**

When a tool's behavior depends on external state (like background color), ensure that state changes are propagated to the tool immediately, not just when the tool is re-initialized.

```typescript
// ❌ BAD: Only update when tool changes
useEffect(() => {
  if (tool === 'eraser') {
    setupEraser(backgroundColor);
  }
}, [tool]); // Missing backgroundColor dependency!

// ✅ GOOD: Update when tool OR background changes
useEffect(() => {
  if (tool === 'eraser') {
    setupEraser(backgroundColor);
  }
}, [tool, backgroundColor]);

// ✅ BETTER: Update brush directly when background changes
useEffect(() => {
  canvas.backgroundColor = backgroundColor;
  if (tool === 'eraser' && canvas.freeDrawingBrush) {
    canvas.freeDrawingBrush.color = backgroundColor;
  }
}, [backgroundColor, tool]);
```

## Performance Impact

**Negligible.** Updating the brush color is a simple property assignment with no measurable performance impact.

## Alternative Solutions Considered

### Alternative 1: Re-initialize Eraser Tool
```typescript
// Re-create the entire eraser brush
if (tool === 'eraser') {
  setupEraserTool(canvas, backgroundColor, brushSize);
}
```
**Rejected:** Unnecessary overhead, creates new brush object

### Alternative 2: Force Tool Re-selection
```typescript
// Force user to re-select eraser tool
setTool('none');
setTool('eraser');
```
**Rejected:** Poor UX, interrupts user workflow

### Alternative 3: Direct Property Update (CHOSEN)
```typescript
// Simply update the color property
canvas.freeDrawingBrush.color = backgroundColor;
```
**Chosen:** Minimal code, no overhead, immediate effect

## Version

- Fixed in: v105
- Related to: v102 (path locking), v103 (canvas system), v104 (selection frame)
