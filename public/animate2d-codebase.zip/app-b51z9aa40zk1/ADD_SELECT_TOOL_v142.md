# Add Dedicated Select Tool - v142

## Issue

The multi-select feature was interfering with shape drawing. When users tried to draw shapes (rectangle, circle, triangle), the selection box would appear instead of the shape being drawn, making it impossible to create shapes properly.

### Root Cause

In v141, we enabled `canvas.selection = true` for all non-drawing tools (including shape tools). This meant:

- Shape tools: selection box appeared when clicking and dragging
- User wanted to draw a rectangle: selection box appeared instead
- User wanted to draw a circle: selection box appeared instead
- Shapes couldn't be drawn properly

## Solution

Add a dedicated "Select" tool to the toolbar that users can explicitly switch to when they want to multi-select objects. This way:

- **Select tool**: Enables multi-selection box
- **Shape tools**: Draw shapes without interference
- **Drawing tools**: Draw freely without selection box
- **Other tools**: Work normally without selection box

## Implementation

### 1. Add 'select' to Tool Type

```typescript
// src/components/editor/types/spriteEditor.ts
export type Tool = 'select' | 'pencil' | 'brush' | 'eraser' | 'line' | 'rectangle' | 'circle' | 'triangle' | 'fill' | 'smudge' | 'blur' | 'glow' | 'text' | 'image';
```

### 2. Add MousePointer Icon Import

```typescript
import { 
  Pencil, 
  Eraser, 
  Square, 
  Circle, 
  Triangle, 
  Type,
  Image as ImageIcon,
  Trash2,
  Lock,
  Unlock,
  MousePointer // ✅ New icon for select tool
} from 'lucide-react';
```

### 3. Add Select Tool to Toolbar

```typescript
const tools = [
  { type: 'select', icon: <MousePointer className="w-4 h-4" />, label: 'Select' }, // ✅ First tool
  { type: 'brush', icon: <Pencil className="w-4 h-4" />, label: 'Brush' },
  { type: 'eraser', icon: <Eraser className="w-4 h-4" />, label: 'Eraser' },
  { type: 'line', icon: <svg>...</svg>, label: 'Line' },
  { type: 'rectangle', icon: <Square className="w-4 h-4" />, label: 'Rectangle' },
  { type: 'circle', icon: <Circle className="w-4 h-4" />, label: 'Circle' },
  { type: 'triangle', icon: <Triangle className="w-4 h-4" />, label: 'Triangle' },
  { type: 'text', icon: <Type className="w-4 h-4" />, label: 'Text' },
];
```

### 4. Update Selection Logic

```typescript
useEffect(() => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  const isDrawingTool = ['brush', 'eraser'].includes(drawingState.tool);
  const isSelectTool = drawingState.tool === 'select'; // ✅ Check if select tool

  if (isDrawingTool) {
    canvas.isDrawingMode = true;
    canvas.selection = false; // No selection box for drawing
  } else {
    canvas.isDrawingMode = false;
    canvas.selection = isSelectTool; // ✅ Only enable for select tool
  }
}, [drawingState.tool, /* ... */]);
```

### 5. Add Keyboard Shortcut

```typescript
// 'V' key for select tool (standard in design tools like Figma, Sketch)
case 'v':
  e.preventDefault();
  setTool('select');
  break;
```

### 6. Update Tool Property Checks

```typescript
// Select tool doesn't need color picker
const needsColor = !['eraser', 'select'].includes(drawingState.tool);

// Select tool doesn't need brush size
const needsBrushSize = ['brush', 'eraser'].includes(drawingState.tool);

// Select tool doesn't need stroke width
const needsStrokeWidth = ['line', 'rectangle', 'circle', 'triangle'].includes(drawingState.tool);
```

## How It Works

### Tool Behavior Matrix

| Tool | Drawing Mode | Selection Box | Click Empty Space | Click Object | Drag Empty Space | Drag Object |
|------|--------------|---------------|-------------------|--------------|------------------|-------------|
| **Select** | ❌ No | ✅ Yes | Deselect all | Select object | Selection box | Move object |
| **Brush** | ✅ Yes | ❌ No | Start drawing | Start drawing | Draw stroke | Draw stroke |
| **Eraser** | ✅ Yes | ❌ No | Start erasing | Start erasing | Erase | Erase |
| **Rectangle** | ❌ No | ❌ No | Start shape | Select object | Draw rectangle | Move object |
| **Circle** | ❌ No | ❌ No | Start shape | Select object | Draw circle | Move object |
| **Triangle** | ❌ No | ❌ No | Start shape | Select object | Draw triangle | Move object |
| **Line** | ❌ No | ❌ No | Start line | Select object | Draw line | Move object |
| **Text** | ❌ No | ❌ No | Add text | Select object | - | Move object |
| **Image** | ❌ No | ❌ No | - | Select object | - | Move object |

### Selection Box Behavior

**Select Tool Active**:
```
User clicks and drags on empty space
    ↓
Selection box appears
    ↓
All objects inside box are selected
    ↓
User can move/delete/transform them together
```

**Shape Tool Active**:
```
User clicks and drags on empty space
    ↓
Shape starts drawing
    ↓
Shape follows mouse
    ↓
Shape is created on mouse release
```

## User Experience

### Before Fix (v141)

**Drawing a Rectangle**:
1. Select rectangle tool
2. Click and drag on canvas
3. ❌ Blue selection box appears
4. ❌ No rectangle is drawn
5. ❌ Frustrating and broken

**Drawing a Circle**:
1. Select circle tool
2. Click and drag on canvas
3. ❌ Blue selection box appears
4. ❌ No circle is drawn
5. ❌ Can't use shape tools

### After Fix (v142)

**Drawing a Rectangle**:
1. Select rectangle tool
2. Click and drag on canvas
3. ✅ Rectangle is drawn
4. ✅ No selection box interference
5. ✅ Works as expected

**Multi-Selecting Objects**:
1. Select select tool (V key or click icon)
2. Click and drag around objects
3. ✅ Selection box appears
4. ✅ All objects inside are selected
5. ✅ Can move/delete them together

## Keyboard Shortcuts

| Key | Tool | Description |
|-----|------|-------------|
| **V** | Select | Multi-select objects |
| B | Brush | Draw with pencil |
| E | Eraser | Erase objects |
| R | Rectangle | Draw rectangles |
| C | Circle | Draw circles |
| T | Text | Add text |
| L | Line | Draw lines |
| I | Image | Add images |

**Note**: 'V' is the standard shortcut for the select tool in professional design tools like Figma, Sketch, Adobe XD, and Photoshop.

## Testing

### Test 1: Select Tool - Multi-Select
1. Add 3 shapes to canvas
2. Press 'V' or click select tool
3. ✅ Select tool icon highlighted
4. Click and drag around all 3 shapes
5. ✅ Selection box appears
6. ✅ All 3 shapes selected
7. Drag to move
8. ✅ All 3 shapes move together

### Test 2: Rectangle Tool - No Interference
1. Press 'R' or click rectangle tool
2. ✅ Rectangle tool icon highlighted
3. Click and drag on canvas
4. ✅ Rectangle is drawn
5. ✅ No selection box appears
6. Release mouse
7. ✅ Rectangle is created

### Test 3: Circle Tool - No Interference
1. Press 'C' or click circle tool
2. ✅ Circle tool icon highlighted
3. Click and drag on canvas
4. ✅ Circle is drawn
5. ✅ No selection box appears
6. Release mouse
7. ✅ Circle is created

### Test 4: Triangle Tool - No Interference
1. Click triangle tool
2. ✅ Triangle tool icon highlighted
3. Click and drag on canvas
4. ✅ Triangle is drawn
5. ✅ No selection box appears
6. Release mouse
7. ✅ Triangle is created

### Test 5: Line Tool - No Interference
1. Press 'L' or click line tool
2. ✅ Line tool icon highlighted
3. Click and drag on canvas
4. ✅ Line is drawn
5. ✅ No selection box appears
6. Release mouse
7. ✅ Line is created

### Test 6: Switch Between Tools
1. Press 'V' (select tool)
2. ✅ Can multi-select
3. Press 'R' (rectangle tool)
4. ✅ Can draw rectangles
5. Press 'V' again
6. ✅ Can multi-select again
7. Press 'B' (brush tool)
8. ✅ Can draw freely

### Test 7: Select Tool - Single Object
1. Add a shape to canvas
2. Press 'V' (select tool)
3. Click on the shape
4. ✅ Shape is selected
5. Drag the shape
6. ✅ Shape moves
7. Click empty space
8. ✅ Shape is deselected

### Test 8: Brush Tool - No Selection Box
1. Press 'B' (brush tool)
2. Click and drag on canvas
3. ✅ Draws stroke
4. ✅ No selection box
5. Press 'V' (select tool)
6. Click and drag on canvas
7. ✅ Selection box appears

## Benefits

✅ **Shape Tools Work**: Can draw shapes without interference
✅ **Explicit Control**: User chooses when to multi-select
✅ **Professional**: Matches industry-standard design tools
✅ **Intuitive**: Clear separation between tools
✅ **Flexible**: Multi-select available when needed
✅ **Keyboard Shortcut**: Fast switching with 'V' key

## Comparison

| Aspect | v141 (Before) | v142 (After) |
|--------|---------------|--------------|
| Draw rectangle | ❌ Selection box | ✅ Rectangle drawn |
| Draw circle | ❌ Selection box | ✅ Circle drawn |
| Draw triangle | ❌ Selection box | ✅ Triangle drawn |
| Draw line | ❌ Selection box | ✅ Line drawn |
| Multi-select | ✅ Always on | ✅ Select tool only |
| User control | ❌ No control | ✅ Full control |
| Shape tools usable | ❌ No | ✅ Yes |

## Design Rationale

### Why a Dedicated Select Tool?

**Industry Standard**:
- Figma: 'V' key for select tool
- Sketch: 'V' key for select tool
- Adobe XD: 'V' key for select tool
- Photoshop: 'V' key for move tool
- Illustrator: 'V' key for selection tool

**User Expectations**:
- Users familiar with design tools expect a select tool
- Clear visual indication of current mode
- Explicit control over multi-selection

**Functional Separation**:
- Drawing tools: Create new content
- Shape tools: Create new shapes
- Select tool: Manipulate existing objects
- Each tool has a clear, single purpose

### Why Not Auto-Enable for All Object Tools?

**Problem with Auto-Enable**:
- Shape tools need to create shapes on drag
- Selection box interferes with shape creation
- User can't draw shapes properly
- Confusing behavior

**Solution with Dedicated Tool**:
- Shape tools create shapes
- Select tool enables multi-selection
- Clear separation of concerns
- Predictable behavior

## Toolbar Layout

```
┌─────────────────────────────────────┐
│ [Select] [Brush] [Eraser] [Line]   │
│ [Rectangle] [Circle] [Triangle]    │
│ [Text]                              │
└─────────────────────────────────────┘
```

**Select tool is first** because:
- Most commonly used tool
- Default tool in most design apps
- Easy to access
- Matches user expectations

## Files Modified

- `src/components/editor/types/spriteEditor.ts`
  - Added 'select' to Tool type

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Added MousePointer icon import
  - Added select tool to tools array
  - Updated selection logic to only enable for select tool
  - Added 'V' keyboard shortcut for select tool
  - Updated needsColor to exclude select tool

## Version

- v142: Add dedicated select tool
- Select tool enables multi-selection
- Shape tools work without interference
- Keyboard shortcut: 'V' key
- Professional design tool behavior ✅

## Related

- Tool management
- Canvas selection
- Shape drawing
- Multi-select functionality
- User experience
- Industry standards
