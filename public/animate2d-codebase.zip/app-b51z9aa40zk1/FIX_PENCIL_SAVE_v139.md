# Fix Pencil and Eraser Auto-Save - v139

## Issue

Objects drawn with the pencil/brush tool were not being saved automatically. Additionally, erased parts and images were not triggering auto-save. Users would draw with the pencil, refresh the page, and find their drawings missing.

### Affected Tools

- ❌ Pencil/Brush strokes not saved
- ❌ Eraser modifications not saved
- ✅ Shapes (rectangle, circle, etc.) saved correctly
- ✅ Text saved correctly
- ✅ Line tool saved correctly

## Root Cause

The `path:created` event handler, which fires when pencil/brush strokes are completed, was not calling `autoSaveCanvas()`.

### Event Flow

**Pencil/Brush Drawing**:
```
User draws with pencil
    ↓
Mouse up
    ↓
Fabric.js fires 'path:created' event
    ↓
Path object created and locked
    ↓
❌ No auto-save called
    ↓
Drawing not persisted
```

**Shape Drawing** (Working):
```
User draws shape
    ↓
Mouse up
    ↓
Shape object added to canvas
    ↓
Fabric.js fires 'object:added' event
    ↓
✅ autoSaveCanvas() called
    ↓
Drawing persisted
```

### Why This Happened

The `path:created` event is specific to free drawing (pencil/brush/eraser) and is fired before `object:added`. The handler was setting up the path properties but not triggering auto-save.

```typescript
// Before (Missing auto-save)
canvas.on('path:created', (e: any) => {
  const path: fabric.Path = e.path;
  
  if (isEraserPath) {
    console.log('[ERASER] Eraser path created, not locking');
    return; // ❌ No auto-save
  }
  
  // Lock brush paths
  path.set({ /* ... */ });
  canvas.renderAll();
  // ❌ No auto-save here either
});
```

## Solution

Added `autoSaveCanvas()` calls in the `path:created` event handler for both brush strokes and eraser strokes.

### Implementation

```typescript
// After (With auto-save)
canvas.on('path:created', (e: any) => {
  const path: fabric.Path = e.path;
  
  if (isEraserPath) {
    console.log('[ERASER] Eraser path created, not locking');
    autoSaveCanvas(); // ✅ Save after eraser stroke
    return;
  }
  
  // Lock brush paths
  path.set({ /* ... */ });
  canvas.renderAll();
  
  autoSaveCanvas(); // ✅ Save after brush stroke
});
```

### Why This Works

- `path:created` fires immediately after pencil/brush stroke completes
- Calling `autoSaveCanvas()` triggers the debounced save (500ms delay)
- Both brush strokes and eraser strokes now trigger auto-save
- Consistent with other drawing tools (shapes, text, etc.)

## Auto-Save Events

All canvas modifications now trigger auto-save:

| Event | Tool | Status |
|-------|------|--------|
| `path:created` | Pencil/Brush | ✅ Fixed |
| `path:created` | Eraser | ✅ Fixed |
| `object:added` | Shapes, Text, Image | ✅ Working |
| `object:modified` | Move, Resize, Edit | ✅ Working |
| `object:removed` | Delete | ✅ Working |

## User Experience

### Before Fix

1. User draws with pencil
2. Header shows "Unsaved changes"
3. Wait 500ms
4. ❌ Still shows "Unsaved changes"
5. Refresh page
6. ❌ Drawing is gone

### After Fix

1. User draws with pencil
2. Header shows "Unsaved changes"
3. Wait 500ms
4. ✅ Shows "Auto-saving..."
5. ✅ Shows "All changes saved"
6. Refresh page
7. ✅ Drawing is restored

## Technical Details

### Path Created Event

The `path:created` event is fired by Fabric.js when:
- User completes a free drawing stroke (pencil/brush)
- User completes an eraser stroke
- The path object is created but not yet added to canvas

### Auto-Save Debounce

The auto-save system uses a 500ms debounce:

```typescript
const autoSaveCanvas = useCallback(() => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  // Clear existing timeout
  if (autoSaveTimeoutRef.current) {
    clearTimeout(autoSaveTimeoutRef.current);
  }

  // Set unsaved status
  setSaveStatus('unsaved');

  // Debounce: save after 500ms
  autoSaveTimeoutRef.current = setTimeout(() => {
    setSaveStatus('saving');
    
    try {
      const canvasJSON = JSON.stringify(canvas.toJSON());
      saveCanvasVersion(/* ... */);
      setSaveStatus('saved');
    } catch (error) {
      console.error('[AUTO-SAVE] Failed:', error);
      setSaveStatus('unsaved');
    }
  }, 500);
}, [/* ... */]);
```

### Why Debounce Matters

- User might draw multiple strokes quickly
- Each stroke triggers `autoSaveCanvas()`
- Debounce prevents saving after every stroke
- Only saves 500ms after last stroke
- Efficient and performant

## Eraser Behavior

The eraser has special handling:

```typescript
if ((path as any).isEraser || 
    (canvas.freeDrawingBrush as any).constructor.name === 'EraserBrush') {
  console.log('[ERASER] Eraser path created, not locking');
  autoSaveCanvas(); // ✅ Save eraser modifications
  return;
}
```

**Why Eraser Paths Aren't Locked**:
- Eraser paths need to be processed by erase2d library
- They modify existing objects rather than creating new ones
- Locking them would prevent the eraser from working
- Auto-save still triggered to persist the modifications

## Testing

### Test 1: Pencil Drawing
1. Select pencil tool
2. Draw a stroke
3. ✅ Header shows "Unsaved changes"
4. Wait 500ms
5. ✅ Header shows "Auto-saving..."
6. ✅ Header shows "All changes saved"
7. Refresh page
8. ✅ Stroke is restored

### Test 2: Multiple Strokes
1. Draw 5 quick strokes
2. ✅ Header shows "Unsaved changes"
3. Wait 500ms after last stroke
4. ✅ Header shows "Auto-saving..."
5. ✅ Header shows "All changes saved"
6. Refresh page
7. ✅ All 5 strokes restored

### Test 3: Eraser
1. Draw some strokes
2. Select eraser
3. Erase part of a stroke
4. ✅ Header shows "Unsaved changes"
5. Wait 500ms
6. ✅ Header shows "Auto-saving..."
7. ✅ Header shows "All changes saved"
8. Refresh page
9. ✅ Erased state is restored

### Test 4: Mixed Tools
1. Draw with pencil
2. Draw a rectangle
3. Add text
4. Erase something
5. ✅ All modifications trigger auto-save
6. Refresh page
7. ✅ Everything restored correctly

### Test 5: Image Upload
1. Upload an image
2. ✅ `object:added` event fires
3. ✅ Auto-save triggered
4. Refresh page
5. ✅ Image restored

## Benefits

✅ **No Lost Work**: Pencil drawings now saved automatically
✅ **Consistent**: All tools trigger auto-save
✅ **Reliable**: Eraser modifications persisted
✅ **User Confidence**: Visual feedback shows save status
✅ **Professional**: Matches expected behavior

## Comparison

### Before vs After

| Scenario | Before | After |
|----------|--------|-------|
| Draw with pencil | ❌ Not saved | ✅ Saved |
| Draw multiple strokes | ❌ Not saved | ✅ All saved |
| Use eraser | ❌ Not saved | ✅ Saved |
| Upload image | ✅ Saved | ✅ Saved |
| Draw shapes | ✅ Saved | ✅ Saved |
| Add text | ✅ Saved | ✅ Saved |
| Refresh page | ❌ Pencil work lost | ✅ Everything restored |

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Added `autoSaveCanvas()` call after brush stroke creation
  - Added `autoSaveCanvas()` call after eraser stroke creation
  - Both calls in the `path:created` event handler

## Version

- v139: Fix pencil and eraser auto-save
- Pencil/brush strokes now saved automatically
- Eraser modifications now saved automatically
- All drawing tools trigger auto-save consistently ✅

## Related

- Auto-save system
- Fabric.js events
- Path creation
- Debouncing
- State persistence
