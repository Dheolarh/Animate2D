# Stroke Uniform Fix - v125

## The Problem

When scaling objects (rectangles, circles, etc.), the stroke width was scaling with the object, making the border thicker or thinner. This is visually incorrect - stroke width should remain constant regardless of object size.

**Example**:
- Draw a rectangle with 2px stroke
- Scale it to 200%
- Stroke becomes 4px (incorrect)
- Should stay 2px (correct)

## The Solution

Set `strokeUniform: true` on the Fabric.js Object prototype.

```typescript
fabric.Object.prototype.set({
  // ... other properties
  strokeUniform: true, // Keep stroke width constant when scaling
});
```

## How It Works

### strokeUniform: false (Default - Incorrect)
- Stroke width scales with object
- 2px stroke → scale 2x → 4px stroke
- Visually inconsistent
- Not what users expect

### strokeUniform: true (Fixed - Correct)
- Stroke width stays constant
- 2px stroke → scale 2x → still 2px stroke
- Visually consistent
- Matches professional design tools

## Testing

### Test 1: Scale Rectangle
1. Draw a rectangle with stroke
2. Select and scale it larger
3. ✅ Stroke width should stay the same
4. Scale it smaller
5. ✅ Stroke width should still stay the same

### Test 2: Scale Circle
1. Draw a circle with stroke
2. Scale it to different sizes
3. ✅ Stroke should always be the same width

### Test 3: Scale Triangle
1. Draw a triangle with stroke
2. Scale and rotate it
3. ✅ Stroke width should remain constant

## Benefits

✅ **Visual Consistency**: Stroke width stays predictable
✅ **Professional Behavior**: Matches Illustrator, Figma, Sketch
✅ **User Expectation**: What designers expect
✅ **Clean Scaling**: Objects scale without distorting strokes

## Comparison

### Before (strokeUniform: false)
```
Original: ▭ (2px stroke)
Scaled:   ▭ (4px stroke) ❌ Wrong!
```

### After (strokeUniform: true)
```
Original: ▭ (2px stroke)
Scaled:   ▭ (2px stroke) ✅ Correct!
```

## Technical Details

The `strokeUniform` property:
- Controls how stroke width responds to scaling
- `true`: Stroke width in absolute pixels
- `false`: Stroke width scales with object
- Applies to all stroked objects (shapes, paths, lines)

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Added `strokeUniform: true` to Object prototype

## Version

- v125: Fixed stroke scaling by setting strokeUniform to true
- Fabric.js: 7.3.1
- Status: Stroke width now stays constant when scaling ✅

## Related

- Fabric.js strokeUniform documentation
- Professional design tool behavior
- Vector graphics best practices

## Update: Explicit strokeUniform Setting

### Issue Found
Even with `strokeUniform: true` on the prototype, some objects (especially rectangles) were still scaling their strokes. This happened because the property wasn't being properly inherited during object creation.

### Additional Fix
Explicitly set `strokeUniform: true` in the configuration object when creating shapes and lines:

```typescript
// For shapes (rectangle, circle, triangle)
const shapeConfig = {
  fill: shapeFillMode === 'fill' ? drawingState.color : '',
  stroke: shapeFillMode === 'stroke' ? drawingState.color : '',
  strokeWidth: shapeFillMode === 'stroke' ? drawingState.brushSize : 0,
  strokeUniform: true, // CRITICAL: Explicitly set for each shape
  // ... other properties
};

// For lines
const line = new fabric.Line([x1, y1, x2, y2], {
  stroke: drawingState.color,
  strokeWidth: drawingState.brushSize,
  strokeUniform: true, // CRITICAL: Explicitly set for lines
  // ... other properties
});
```

### Why Both?
1. **Prototype setting**: Applies to objects created by Fabric.js internally (like brush paths)
2. **Explicit setting**: Ensures our manually created objects definitely have the property

This double-setting approach guarantees all objects have uniform strokes.

## Version Update

- v125: Initial fix with prototype setting
- v125.1: Added explicit strokeUniform to shape and line creation
- Status: All strokes now stay constant when scaling ✅
