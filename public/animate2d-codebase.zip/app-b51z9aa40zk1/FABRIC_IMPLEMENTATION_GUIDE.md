# Fabric.js Canvas Implementation Guide

## Complete Step-by-Step Implementation

This document explains the proper way to implement a Fabric.js canvas system without bugs, based on best practices and the official Fabric.js documentation.

---

## Core Principles

### 1. **Separation of Concerns**
- **Drawing tools** (brush, eraser) use `isDrawingMode = true`
- **Shape tools** (rectangle, circle, line) use custom mouse event handlers
- **Selection tools** use default Fabric.js selection behavior

### 2. **Path Locking**
- ALL brush and eraser paths must be locked immediately on creation
- Locking happens in the `path:created` event BEFORE selection events fire
- Locked paths should never be selectable, evented, or have controls

### 3. **Shape Drawing Flow**
- Create shapes with `selectable: false` during drawing
- Update shape dimensions during `mouse:move`
- Make shapes selectable on `mouse:up` and set as active object

---

## Step 1: Canvas Initialization

```typescript
const canvas = new fabric.Canvas(canvasRef.current, {
  width: 800,
  height: 600,
  backgroundColor: '#ffffff',
  preserveObjectStacking: true,  // Maintain z-order
  selection: true,                // Enable selection
});
```

### Key Options:
- `preserveObjectStacking`: Keeps objects in the order they were added
- `selection`: Enables multi-select and selection box

---

## Step 2: Configure Selection Controls

**CRITICAL:** Set these on the prototype BEFORE creating any objects:

```typescript
fabric.Object.prototype.set({
  borderColor: 'rgba(0, 0, 0, 0.6)',      // Selection border color
  cornerColor: 'rgba(0, 0, 0, 0.9)',      // Corner handle color
  cornerStyle: 'circle',                   // Circle or rect corners
  cornerSize: 12,                          // Size of corner handles
  transparentCorners: false,               // Solid corner handles
  borderScaleFactor: 2,                    // Border thickness
  padding: 8,                              // Padding around object
  borderDashArray: [5, 5],                 // Dashed border (optional)
});
```

### Why This Matters:
- These settings apply to ALL objects created after this point
- Setting them on the prototype ensures consistency
- Must be done BEFORE creating any objects

---

## Step 3: Lock All Brush/Eraser Paths

**CRITICAL FIX:** This is the most important step to prevent selection bugs.

```typescript
canvas.on('path:created', (e: any) => {
  const path: fabric.Path = e.path;
  
  // Lock the path completely
  path.set({
    selectable: false,
    evented: false,
    hasControls: false,
    hasBorders: false,
    lockMovementX: true,
    lockMovementY: true,
    lockRotation: true,
    lockScalingX: true,
    lockScalingY: true,
  });
  
  // Tag it for identification
  (path as any).__locked__ = true;
  
  // Discard any active selection
  canvas.discardActiveObject();
  canvas.renderAll();
});
```

### Why This Works:
- `path:created` fires BEFORE `selection:created`
- Locking the path prevents it from participating in selection
- Discarding active object prevents selection flash
- The `__locked__` tag allows identification later

### What NOT to Do:
❌ Don't try to prevent selection in `selection:created` - too late!
❌ Don't use color matching - unreliable when background changes
❌ Don't leave paths selectable and try to filter them out

---

## Step 4: Setup Drawing Tools (Brush & Eraser)

```typescript
// Brush Tool
if (tool === 'brush') {
  canvas.isDrawingMode = true;
  const brush = new fabric.PencilBrush(canvas);
  brush.color = color;
  brush.width = brushSize;
  (brush as any).opacity = opacity / 100;  // 0-1 range
  canvas.freeDrawingBrush = brush;
}

// Eraser Tool
if (tool === 'eraser') {
  canvas.isDrawingMode = true;
  const eraser = new fabric.PencilBrush(canvas);
  eraser.color = backgroundColor;  // Same as canvas background
  eraser.width = brushSize;
  canvas.freeDrawingBrush = eraser;
}

// Other Tools (disable drawing mode)
if (tool !== 'brush' && tool !== 'eraser') {
  canvas.isDrawingMode = false;
}
```

### Key Points:
- `isDrawingMode = true` enables free drawing
- Eraser is just a brush with background color
- Opacity is set on the brush object, not the color string
- Always disable drawing mode for non-drawing tools

---

## Step 5: Shape Drawing (Rectangle, Circle, Triangle, Line)

### Mouse Down - Create Shape

```typescript
canvas.on('mouse:down', (e) => {
  if (canvas.isDrawingMode) return;  // Skip if drawing mode
  
  const pointer = canvas.getPointer(e.e);
  
  // Create shape with selectable: false
  const shape = new fabric.Rect({
    left: pointer.x,
    top: pointer.y,
    width: 0,
    height: 0,
    fill: fillMode === 'fill' ? color : '',
    stroke: fillMode === 'stroke' ? color : '',
    strokeWidth: fillMode === 'stroke' ? strokeWidth : 0,
    selectable: false,    // CRITICAL: Not selectable during drawing
    evented: false,       // CRITICAL: No events during drawing
    hasControls: false,   // CRITICAL: No controls during drawing
    hasBorders: false,    // CRITICAL: No borders during drawing
  });
  
  canvas.add(shape);
  currentShape = shape;
  isDrawing = true;
  canvas.renderAll();
});
```

### Mouse Move - Update Shape

```typescript
canvas.on('mouse:move', (e) => {
  if (!isDrawing || !currentShape) return;
  
  const pointer = canvas.getPointer(e.e);
  
  // Update shape dimensions
  if (currentShape instanceof fabric.Rect) {
    const width = Math.abs(pointer.x - startX);
    const height = Math.abs(pointer.y - startY);
    currentShape.set({
      left: Math.min(startX, pointer.x),
      top: Math.min(startY, pointer.y),
      width: width,
      height: height,
    });
  }
  
  canvas.renderAll();
});
```

### Mouse Up - Make Selectable

```typescript
canvas.on('mouse:up', () => {
  if (!isDrawing || !currentShape) return;
  
  // CRITICAL: Make shape selectable AFTER drawing is complete
  currentShape.set({
    selectable: true,
    evented: true,
    hasControls: true,
    hasBorders: true,
  });
  
  // Set as active object so user can see selection
  canvas.setActiveObject(currentShape);
  canvas.renderAll();
  
  isDrawing = false;
  currentShape = null;
});
```

### Why This Pattern Works:
1. Shape is created with `selectable: false` - prevents interference during drawing
2. Shape dimensions are updated during mouse move
3. Shape is made selectable on mouse up - user can now manipulate it
4. `setActiveObject()` shows selection controls immediately

---

## Step 6: Text Tool

```typescript
if (tool === 'text') {
  const pointer = canvas.getPointer(e.e);
  
  const text = new fabric.IText('Text', {
    left: pointer.x,
    top: pointer.y,
    fill: color,
    fontSize: 24,
    fontFamily: 'Arial',
  });
  
  canvas.add(text);
  canvas.setActiveObject(text);
  text.enterEditing();  // Start editing immediately
  canvas.renderAll();
}
```

### Key Points:
- Use `IText` for editable text
- Call `enterEditing()` to start editing immediately
- Text is selectable by default (correct behavior)

---

## Step 7: Image Tool

```typescript
if (tool === 'image') {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'image/*';
  
  fileInput.onchange = (e) => {
    const file = (e.target as HTMLInputElement).files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const imgUrl = event.target?.result as string;
      
      fabric.Image.fromURL(imgUrl, (img) => {
        // Scale image to fit canvas
        const scale = Math.min(
          canvasWidth / (img.width || 1) * 0.5,
          canvasHeight / (img.height || 1) * 0.5
        );
        
        img.set({
          left: canvasWidth / 2,
          top: canvasHeight / 2,
          originX: 'center',
          originY: 'center',
          scaleX: scale,
          scaleY: scale,
        });
        
        canvas.add(img);
        canvas.setActiveObject(img);
        canvas.renderAll();
      }, { crossOrigin: 'anonymous' });
    };
    
    reader.readAsDataURL(file);
  };
  
  fileInput.click();
}
```

---

## Step 8: Delete Selected Objects

```typescript
const deleteSelected = () => {
  const activeObjects = canvas.getActiveObjects();
  
  if (activeObjects.length > 0) {
    activeObjects.forEach((obj) => canvas.remove(obj));
    canvas.discardActiveObject();
    canvas.renderAll();
  }
};

// Keyboard shortcut
document.addEventListener('keydown', (e) => {
  if (e.key === 'Delete' || e.key === 'Backspace') {
    deleteSelected();
  }
});
```

---

## Step 9: Save and Load Canvas State

### Save State

```typescript
const saveState = (): string => {
  return JSON.stringify(canvas.toJSON());
};
```

### Load State

```typescript
const loadState = (state: string) => {
  if (!state) {
    canvas.clear();
    canvas.renderAll();
    return;
  }
  
  try {
    canvas.loadFromJSON(state, () => {
      canvas.renderAll();
    });
  } catch (error) {
    console.error('Error loading canvas state:', error);
    canvas.clear();
    canvas.renderAll();
  }
};
```

---

## Common Pitfalls and Solutions

### Pitfall 1: Shapes Not Selectable After Drawing
**Problem:** Forgot to set `selectable: true` on mouse up
**Solution:** Always call `shape.set({ selectable: true, evented: true, hasControls: true, hasBorders: true })` after drawing

### Pitfall 2: Brush Strokes Become Selectable
**Problem:** Not locking paths in `path:created` event
**Solution:** Lock ALL paths immediately in `path:created` event

### Pitfall 3: Selection Controls Not Visible
**Problem:** Selection controls not configured or configured after objects created
**Solution:** Set `fabric.Object.prototype` BEFORE creating any objects

### Pitfall 4: Shapes Lose Selection Over Erased Areas
**Problem:** Using `selection:created` to prevent eraser selection (too late!)
**Solution:** Lock paths in `path:created` event (before selection events)

### Pitfall 5: Eraser Paths Interfere with Selection
**Problem:** Eraser paths are regular objects competing for selection
**Solution:** Lock eraser paths with `selectable: false` and `evented: false`

---

## Testing Checklist

- [ ] Brush strokes are NOT selectable
- [ ] Eraser strokes are NOT selectable
- [ ] Rectangles are selectable after drawing
- [ ] Circles are selectable after drawing
- [ ] Triangles are selectable after drawing
- [ ] Lines are selectable after drawing
- [ ] Text is editable and selectable
- [ ] Images are selectable and resizable
- [ ] Shapes drawn over erased areas are fully selectable
- [ ] Shapes drawn over brush strokes are fully selectable
- [ ] Selection controls are visible and functional
- [ ] Multi-select works correctly
- [ ] Delete key removes selected objects
- [ ] Save/load preserves all objects and properties

---

## Performance Tips

1. **Batch Operations:** Call `renderAll()` once after multiple changes
2. **Dispose Properly:** Always call `canvas.dispose()` on unmount
3. **Limit Onion Skin:** Keep frame count low (3-5 frames)
4. **Optimize State Saves:** Only save on modification, not every render
5. **Use Refs:** Store drawing state in refs to avoid re-renders

---

## References

- Fabric.js Official Documentation: http://fabricjs.com/docs/
- Fabric.js GitHub: https://github.com/fabricjs/fabric.js
- Fabric.js Demos: http://fabricjs.com/demos/

---

## Summary

The key to a bug-free Fabric.js implementation:

1. **Lock paths immediately** in `path:created` event
2. **Create shapes with selectable: false** during drawing
3. **Make shapes selectable** on mouse up
4. **Configure selection controls** on prototype before creating objects
5. **Separate drawing mode** from shape drawing
6. **Test thoroughly** with all tool combinations

Follow these principles and your Fabric.js canvas will work flawlessly!
