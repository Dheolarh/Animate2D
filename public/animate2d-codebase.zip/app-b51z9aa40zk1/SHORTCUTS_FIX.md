# Keyboard Shortcuts Fix - v129

## Problem

None of the keyboard shortcuts were working because the event handler had stale function references.

## Root Cause

The keyboard shortcuts `useEffect` had a dependency array of `[setTool]`, but it was calling functions like `undo()`, `redo()`, and `deleteSelected()` that weren't in the dependency array. This caused the event handler to have stale references to these functions.

Additionally, `deleteSelected()` was defined twice in the component - once near the top and once near the bottom, causing potential conflicts.

## Solution

### 1. Wrapped Functions with useCallback

Wrapped all functions called by keyboard shortcuts with `React.useCallback` to create stable references:

```typescript
const undo = React.useCallback(() => {
  // ... undo logic
}, []);

const redo = React.useCallback(() => {
  // ... redo logic
}, []);

const deleteSelected = React.useCallback(() => {
  // ... delete logic
}, []);

const saveHistory = React.useCallback(() => {
  // ... save logic
}, []);
```

### 2. Updated Dependency Array

Added all callback functions to the keyboard shortcuts dependency array:

```typescript
useEffect(() => {
  // ... keyboard event handler
  window.addEventListener('keydown', handleKeyDown);
  return () => window.removeEventListener('keydown', handleKeyDown);
}, [setTool, undo, redo, deleteSelected]); // Added dependencies
```

### 3. Removed Duplicate Function

Removed the duplicate `deleteSelected` function that was defined later in the component.

## Why This Fixes It

### Before (Broken)
```typescript
// Functions defined without useCallback
const undo = () => { /* ... */ };
const redo = () => { /* ... */ };

// useEffect with incomplete dependencies
useEffect(() => {
  const handleKeyDown = (e) => {
    undo(); // Stale reference!
    redo(); // Stale reference!
  };
  // ...
}, [setTool]); // Missing undo, redo

// Later in component
const deleteSelected = () => { /* ... */ }; // Duplicate!
```

**Problem**: The event handler captured the initial (undefined or stale) references to `undo`, `redo`, and `deleteSelected`.

### After (Fixed)
```typescript
// Functions wrapped with useCallback
const undo = React.useCallback(() => { /* ... */ }, []);
const redo = React.useCallback(() => { /* ... */ }, []);
const deleteSelected = React.useCallback(() => { /* ... */ }, []);

// useEffect with complete dependencies
useEffect(() => {
  const handleKeyDown = (e) => {
    undo(); // Fresh reference!
    redo(); // Fresh reference!
    deleteSelected(); // Fresh reference!
  };
  // ...
}, [setTool, undo, redo, deleteSelected]); // All dependencies
```

**Solution**: `useCallback` creates stable function references, and including them in the dependency array ensures the event handler always has the current references.

## Testing

### Test 1: Tool Shortcuts
1. Press `B` - Should switch to brush ✅
2. Press `E` - Should switch to eraser ✅
3. Press `R` - Should switch to rectangle ✅

### Test 2: Undo/Redo
1. Draw an object
2. Press `Ctrl+Z` - Object should disappear ✅
3. Press `Ctrl+Y` - Object should reappear ✅

### Test 3: Delete
1. Draw and select an object
2. Press `Delete` - Object should be removed ✅

### Test 4: Arrow Keys
1. Select an object
2. Press arrow keys - Object should move ✅
3. Press `Shift+Arrow` - Object should move faster ✅

### Test 5: Escape
1. Select an object
2. Press `Escape` - Selection should clear ✅

## Technical Details

### useCallback Hook

`React.useCallback` memoizes a function and returns the same reference unless dependencies change:

```typescript
const memoizedCallback = React.useCallback(
  () => {
    doSomething(a, b);
  },
  [a, b], // Only recreate if a or b changes
);
```

### Why Empty Dependency Array?

Our callbacks use refs (`fabricCanvasRef`, `historyRef`, etc.) which don't change, so we use empty dependency arrays `[]`. This creates stable function references that never change.

### Event Handler Dependencies

When a `useEffect` creates an event handler that calls other functions, those functions must be in the dependency array. Otherwise, the handler captures stale references from the initial render.

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Wrapped `undo`, `redo`, `deleteSelected`, `saveHistory` with `useCallback`
  - Updated keyboard shortcuts dependency array
  - Removed duplicate `deleteSelected` function

## Version

- v129: Fixed keyboard shortcuts by adding proper dependencies
- All shortcuts now working correctly ✅

## Related

- React useCallback hook
- React useEffect dependencies
- Event handler closures
- Function reference stability
