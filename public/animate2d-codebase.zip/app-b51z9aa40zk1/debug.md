# Debug Template

first off all there's a copiable folder at the root of the directory delete what is inside and put a single .tsx and .ts script that will contain all the codes from script that are related to the [bug name] bug each script code will be seperated by ==========
