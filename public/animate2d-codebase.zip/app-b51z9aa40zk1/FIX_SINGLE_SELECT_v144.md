# Fix Single Selection in Select Tool - v144

## Issue

When using the Select tool, clicking on an object should select it (single selection), but the custom mouse handlers were potentially interfering with Fabric.js's built-in selection behavior.

## Root Cause

In v143, we set objects to `selectable: true` and `evented: true` when the select tool is active, which should enable selection. However, our custom `handleMouseDown` handler was running for ALL tools, including the select tool.

While the handler did return early when clicking on a target (line 786-789), it was still processing the event before letting Fabric.js handle it, which could potentially cause timing or event propagation issues.

## Solution

Add an early return in `handleMouseDown` specifically for the select tool, so Fabric.js handles ALL mouse events (single selection, multi-selection, dragging) without any interference from our custom handlers.

## Implementation

```typescript
const handleMouseDown = (opt: fabric.TPointerEventInfo) => {
  console.log('[MOUSE DOWN] isDrawingMode:', canvas.isDrawingMode);
  if (canvas.isDrawingMode) return;
  
  // ✅ If select tool is active, let Fabric.js handle everything
  if (drawingState.tool === 'select') {
    console.log('[MOUSE DOWN] Select tool active, letting Fabric.js handle selection');
    return;
  }
  
  // ... rest of custom logic for other tools ...
};
```

## How It Works

### Event Flow with Select Tool

**Before Fix**:
```
User clicks on object with select tool
    ↓
handleMouseDown runs
    ↓
Checks if drawing mode (no)
    ↓
Gets pointer and target
    ↓
Checks if target exists (yes)
    ↓
Returns early
    ↓
Fabric.js handles selection
    ↓
Object is selected ✅ (but with extra processing)
```

**After Fix**:
```
User clicks on object with select tool
    ↓
handleMouseDown runs
    ↓
Checks if drawing mode (no)
    ↓
Checks if select tool (yes)
    ↓
Returns immediately
    ↓
Fabric.js handles selection
    ↓
Object is selected ✅ (clean, no interference)
```

### Tool-Specific Behavior

| Tool | Custom Mouse Handler | Fabric.js Selection | Behavior |
|------|---------------------|---------------------|----------|
| **Select** | ❌ Skipped | ✅ Handles everything | Single select, multi-select, drag |
| **Brush** | ❌ Skipped (drawing mode) | ❌ Disabled | Free drawing |
| **Eraser** | ❌ Skipped (drawing mode) | ❌ Disabled | Erasing |
| **Rectangle** | ✅ Runs | ❌ Disabled | Create rectangles |
| **Circle** | ✅ Runs | ❌ Disabled | Create circles |
| **Triangle** | ✅ Runs | ❌ Disabled | Create triangles |
| **Line** | ✅ Runs | ❌ Disabled | Create lines |
| **Text** | ✅ Runs | ❌ Disabled | Create text |
| **Image** | ✅ Runs | ❌ Disabled | Add images |

## User Experience

### Select Tool Behavior

**Single Selection**:
1. Press 'V' (select tool)
2. Click on an object
3. ✅ Object is selected
4. Click on another object
5. ✅ First object deselected, second object selected

**Multi-Selection**:
1. Press 'V' (select tool)
2. Click and drag on empty space
3. ✅ Selection box appears
4. Drag around multiple objects
5. ✅ All objects inside box are selected

**Deselection**:
1. Have object(s) selected
2. Click on empty space
3. ✅ All objects deselected

**Moving Objects**:
1. Select an object
2. Drag the object
3. ✅ Object moves
4. Release mouse
5. ✅ Object stays selected

## Benefits

✅ **Clean Selection**: No interference from custom handlers
✅ **Fabric.js Native**: Uses Fabric.js's built-in selection logic
✅ **Reliable**: No timing or event propagation issues
✅ **Complete**: Handles single select, multi-select, and dragging
✅ **Performant**: Skips unnecessary processing for select tool

## Testing

### Test 1: Single Selection
1. Press 'V' (select tool)
2. Draw 3 rectangles (switch to R, draw, switch back to V)
3. Click on rectangle 1
4. ✅ Rectangle 1 is selected
5. Click on rectangle 2
6. ✅ Rectangle 1 deselected, rectangle 2 selected
7. Click on rectangle 3
8. ✅ Rectangle 2 deselected, rectangle 3 selected

### Test 2: Multi-Selection
1. Press 'V' (select tool)
2. Have 3 rectangles on canvas
3. Click and drag selection box around all 3
4. ✅ All 3 rectangles selected
5. Drag them
6. ✅ All 3 move together

### Test 3: Deselection
1. Press 'V' (select tool)
2. Select a rectangle
3. ✅ Rectangle is selected
4. Click on empty space
5. ✅ Rectangle is deselected

### Test 4: Move Object
1. Press 'V' (select tool)
2. Click on a rectangle
3. ✅ Rectangle is selected
4. Drag the rectangle
5. ✅ Rectangle moves
6. Release mouse
7. ✅ Rectangle stays selected

### Test 5: Switch Tools
1. Press 'V' (select tool)
2. Select a rectangle
3. ✅ Rectangle is selected
4. Press 'R' (rectangle tool)
5. ✅ Rectangle becomes non-selectable
6. ✅ Selection is cleared
7. Press 'V' (select tool)
8. ✅ Rectangle becomes selectable again

## Comparison

| Aspect | Before | After |
|--------|--------|-------|
| Single selection | ✅ Works (with extra processing) | ✅ Works (clean) |
| Multi-selection | ✅ Works | ✅ Works |
| Event processing | ❌ Custom handler runs | ✅ Skipped for select tool |
| Fabric.js integration | ⚠️ Potential interference | ✅ Clean integration |
| Performance | ⚠️ Extra processing | ✅ Optimized |

## Technical Details

### Why Skip Custom Handler for Select Tool?

**Custom Handler Purpose**:
- Handle object creation (shapes, lines, text)
- Prevent creating objects when something is selected
- Manage selection count for creation logic

**Select Tool Purpose**:
- Select objects (single or multi)
- Move objects
- Resize objects
- No object creation

**Conclusion**:
- Custom handler not needed for select tool
- Fabric.js handles selection natively
- Skipping custom handler prevents any potential interference

### Event Propagation

**With Custom Handler**:
```
Mouse Down Event
    ↓
Custom Handler (processes event)
    ↓
Returns early
    ↓
Fabric.js (handles selection)
```

**Without Custom Handler (Select Tool)**:
```
Mouse Down Event
    ↓
Custom Handler (returns immediately)
    ↓
Fabric.js (handles selection)
```

The second flow is cleaner and more reliable.

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Added early return in `handleMouseDown` for select tool
  - Prevents custom handler from processing events when select tool is active

## Version

- v144: Fix single selection in select tool
- Custom mouse handler skipped for select tool
- Fabric.js handles all selection logic natively
- Clean and reliable selection behavior ✅

## Related

- Object selection
- Event handling
- Fabric.js integration
- Select tool behavior
- Performance optimization
