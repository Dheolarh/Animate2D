# Remove Multi-Select, Keep Single Selection - v146

## Issue

The multi-select feature and dedicated Select tool added complexity to the workflow. Users wanted a simpler approach where:
- Objects are always selectable by tapping on them (single selection)
- No need for a dedicated Select tool
- No multi-select box feature

## Solution

Remove the multi-select feature and Select tool completely, while keeping single selection functionality. Objects are now selectable when using any non-drawing tool (shapes, text, image), allowing users to tap on objects to select them without switching tools.

## Implementation

### 1. Remove 'select' from Tool Type

```typescript
// Before
export type Tool = 'select' | 'pencil' | 'brush' | ...

// After
export type Tool = 'pencil' | 'brush' | 'eraser' | 'line' | 'rectangle' | 'circle' | 'triangle' | 'fill' | 'smudge' | 'blur' | 'glow' | 'text' | 'image';
```

### 2. Remove Select Tool from Toolbar

```typescript
const tools = [
  // ❌ Removed: { type: 'select', icon: <MousePointer />, label: 'Select' },
  { type: 'brush', icon: <Pencil className="w-4 h-4" />, label: 'Brush' },
  { type: 'eraser', icon: <Eraser className="w-4 h-4" />, label: 'Eraser' },
  // ... other tools
];
```

### 3. Disable Multi-Select, Enable Single Selection

```typescript
useEffect(() => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  const isDrawingTool = ['brush', 'eraser'].includes(drawingState.tool);

  if (isDrawingTool) {
    canvas.isDrawingMode = true;
    canvas.selection = false; // ✅ Disable multi-select box
    
    // Make all objects non-selectable in drawing mode
    canvas.getObjects().forEach((obj: fabric.FabricObject) => {
      if ((obj as any).__locked__) return;
      obj.set({
        selectable: false,
        evented: false,
      });
    });
  } else {
    canvas.isDrawingMode = false;
    canvas.selection = false; // ✅ Disable multi-select box for all tools
    
    // Make all objects selectable for single selection
    canvas.getObjects().forEach((obj: fabric.FabricObject) => {
      if ((obj as any).__locked__) return;
      obj.set({
        selectable: true,  // ✅ Enable single selection
        evented: true,
      });
    });
  }
  
  canvas.renderAll();
}, [drawingState.tool, ...]);
```

### 4. Remove Auto-Switch to Select Tool

```typescript
// Before: After creating shape, switch to select tool
setTool('select');
canvas.setActiveObject(shape);

// After: Just select the object, no tool switch
canvas.setActiveObject(shape);
```

### 5. Remove 'V' Keyboard Shortcut

```typescript
// Removed:
// case 'v':
//   e.preventDefault();
//   setTool('select');
//   break;
```

## How It Works

### Tool Behavior Matrix

| Tool | Drawing Mode | Multi-Select Box | Objects Selectable | Click Object | Create New Object |
|------|--------------|------------------|-------------------|--------------|-------------------|
| **Brush** | ✅ Yes | ❌ No | ❌ No | Draws | Draws stroke |
| **Eraser** | ✅ Yes | ❌ No | ❌ No | Erases | Erases |
| **Rectangle** | ❌ No | ❌ No | ✅ Yes | Selects object | Draws rectangle |
| **Circle** | ❌ No | ❌ No | ✅ Yes | Selects object | Draws circle |
| **Triangle** | ❌ No | ❌ No | ✅ Yes | Selects object | Draws triangle |
| **Line** | ❌ No | ❌ No | ✅ Yes | Selects object | Draws line |
| **Text** | ❌ No | ❌ No | ✅ Yes | Selects object | Adds text |
| **Image** | ❌ No | ❌ No | ✅ Yes | Selects object | Adds image |

### Workflow Examples

**Creating and Moving a Rectangle**:
```
1. User presses 'R' (rectangle tool)
2. User draws a rectangle
3. Rectangle is created and selected
4. User can immediately drag to move it
5. User clicks on empty space to deselect
6. User draws another rectangle
7. New rectangle is created and selected
8. User can tap on first rectangle to select it
9. ✅ No tool switching needed
```

**Working with Multiple Objects**:
```
1. User has rectangle tool selected
2. User draws rectangle A
3. Rectangle A is selected
4. User clicks on empty space
5. User draws rectangle B
6. Rectangle B is selected
7. User taps on rectangle A
8. ✅ Rectangle A is selected (single selection)
9. User taps on rectangle B
10. ✅ Rectangle B is selected (A is deselected)
```

**Drawing Mode**:
```
1. User presses 'B' (brush tool)
2. User draws freely
3. ✅ Objects are not selectable
4. ✅ No interference from existing objects
5. User presses 'R' (rectangle tool)
6. ✅ Objects become selectable again
```

## User Experience

### Before (v145)

**Workflow**:
1. Press 'R' to draw rectangle
2. Draw rectangle
3. Tool switches to select
4. Rectangle is selected
5. Want to draw another rectangle
6. Press 'R' again
7. Draw another rectangle
8. Tool switches to select
9. ❌ Repetitive tool switching

**Multi-Select**:
1. Press 'V' (select tool)
2. Click and drag selection box
3. Multiple objects selected
4. ❌ Feature rarely used
5. ❌ Adds complexity

### After (v146)

**Workflow**:
1. Press 'R' to draw rectangle
2. Draw rectangle
3. ✅ Rectangle is selected (no tool switch)
4. ✅ Still on rectangle tool
5. Click empty space to deselect
6. Draw another rectangle
7. ✅ New rectangle is selected
8. ✅ Smooth, simple workflow

**Single Selection**:
1. Have rectangle tool selected
2. Tap on any object
3. ✅ Object is selected
4. Drag to move
5. ✅ Simple and intuitive

## Benefits

✅ **Simpler**: No dedicated Select tool needed
✅ **Intuitive**: Tap on objects to select them
✅ **Efficient**: No tool switching required
✅ **Clean UI**: One less tool in toolbar
✅ **Focused**: Removed rarely-used multi-select feature
✅ **Streamlined**: Simpler mental model for users

## Comparison

| Aspect | v145 (Before) | v146 (After) |
|--------|---------------|--------------|
| Select tool in toolbar | ✅ Yes | ❌ No |
| Multi-select box | ✅ Yes | ❌ No |
| Single selection | ✅ Yes | ✅ Yes |
| Objects selectable | ✅ Only with select tool | ✅ Always (except drawing mode) |
| Tool switching after create | ✅ Auto-switch to select | ❌ No switching |
| Keyboard shortcut 'V' | ✅ Select tool | ❌ Removed |
| Workflow complexity | ❌ Higher | ✅ Lower |
| UI simplicity | ❌ More tools | ✅ Fewer tools |

## Design Rationale

### Why Remove Multi-Select?

**Complexity vs. Value**:
- Multi-select adds UI complexity (dedicated tool)
- Multi-select adds workflow complexity (tool switching)
- Multi-select rarely used in typical drawing workflows
- Single selection covers most use cases

**Simpler Mental Model**:
- **Before**: "I need to switch to select tool to move objects"
- **After**: "I can just tap on objects to select them"

### Why Keep Single Selection?

**Essential Functionality**:
- Users need to move/resize objects after creating them
- Users need to delete specific objects
- Users need to adjust object properties
- Single selection is fundamental to any drawing tool

**Always Available**:
- No tool switching needed
- Works with any non-drawing tool
- Intuitive: tap object → object selected

### Why No Auto-Switch After Create?

**Consistency**:
- User stays on the tool they selected
- Predictable behavior
- No unexpected tool changes

**Efficiency**:
- Can create multiple objects quickly
- Just click empty space between objects
- No need to keep switching tools

## Testing

### Test 1: Single Selection with Rectangle Tool
1. Press 'R' (rectangle tool)
2. Draw rectangle A
3. ✅ Rectangle A is selected
4. Click empty space
5. ✅ Rectangle A is deselected
6. Tap on rectangle A
7. ✅ Rectangle A is selected again

### Test 2: Create Multiple Shapes
1. Press 'R' (rectangle tool)
2. Draw rectangle A
3. ✅ Rectangle A is selected
4. Click empty space
5. Draw rectangle B
6. ✅ Rectangle B is selected
7. ✅ Still on rectangle tool

### Test 3: Switch Between Objects
1. Have 3 rectangles on canvas
2. Press 'R' (rectangle tool)
3. Tap on rectangle 1
4. ✅ Rectangle 1 is selected
5. Tap on rectangle 2
6. ✅ Rectangle 2 is selected, 1 is deselected
7. Tap on rectangle 3
8. ✅ Rectangle 3 is selected, 2 is deselected

### Test 4: Drawing Mode
1. Press 'B' (brush tool)
2. Try to tap on an object
3. ✅ Object is not selectable
4. ✅ Draws instead
5. Press 'R' (rectangle tool)
6. Tap on object
7. ✅ Object is selectable again

### Test 5: No Multi-Select Box
1. Press 'R' (rectangle tool)
2. Click and drag on empty space
3. ✅ No selection box appears
4. ✅ Starts drawing rectangle instead

### Test 6: Text Tool
1. Press 'T' (text tool)
2. Click to add text
3. ✅ Text is selected and in editing mode
4. Click empty space
5. Tap on text
6. ✅ Text is selected

### Test 7: Image Upload
1. Upload an image
2. ✅ Image is added and selected
3. ✅ No tool switch
4. Drag image
5. ✅ Image moves

## Files Modified

- `src/components/editor/types/spriteEditor.ts`
  - Removed 'select' from Tool type

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Removed MousePointer icon import
  - Removed select tool from tools array
  - Updated needsColor to remove 'select' check
  - Updated drawing mode effect to disable multi-select box
  - Updated drawing mode effect to enable single selection for non-drawing tools
  - Removed select tool check from handleMouseDown
  - Removed setTool('select') calls from object creation
  - Removed 'V' keyboard shortcut

## Version

- v146: Remove multi-select, keep single selection
- No dedicated Select tool
- No multi-select box
- Single selection always available (except drawing mode)
- Simpler workflow and UI ✅

## Related

- Tool management
- Object selection
- User workflow
- UI simplification
- User experience
