# Fix Pan Control - v138

## Issue

The pan control was moving the canvas content (drawings) instead of moving the canvas viewport. When users adjusted the pan slider, the objects on the canvas would move within the white canvas box, rather than the entire canvas box moving within the gray viewport.

### Visual Problem

**Before (Incorrect)**:
- Pan slider at -163: Drawing on left side of canvas
- Pan slider at 240: Drawing on right side of canvas
- White canvas box stays in same position
- ❌ Objects move, canvas doesn't

**After (Correct)**:
- Pan slider at -163: Entire canvas (white box) moves left
- Pan slider at 240: Entire canvas (white box) moves right
- Objects stay in same position relative to canvas
- ✅ Canvas moves, objects don't

## Root Cause

The `handlePanChange` function was modifying the Fabric.js viewport transform (`viewportTransform`), which moves the canvas content rather than the canvas container.

### Incorrect Implementation

```typescript
const handlePanChange = (value: number) => {
  setPanValue(value);
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  const vpt = canvas.viewportTransform;
  if (vpt) {
    if (panAxis === 'x') {
      vpt[4] = value;  // ❌ Moves canvas content
    } else {
      vpt[5] = value;  // ❌ Moves canvas content
    }
    canvas.requestRenderAll();
  }
};
```

### Why This Was Wrong

- `viewportTransform[4]` and `viewportTransform[5]` control the canvas content offset
- Modifying these values pans the drawing within the canvas
- The canvas container position remained unchanged
- Result: Objects move, canvas box doesn't

## Solution

Changed the pan control to update the `canvasPosition` state, which moves the entire canvas container.

### Correct Implementation

```typescript
const handlePanChange = (value: number) => {
  setPanValue(value);
  
  // Update canvas container position instead of viewport transform
  setCanvasPosition(prev => {
    if (panAxis === 'x') {
      return { ...prev, x: value };
    } else {
      return { ...prev, y: value };
    }
  });
};
```

### Why This Works

- `canvasPosition` controls the CSS transform of the canvas container
- Updating this state moves the entire canvas element
- The canvas content maintains its position relative to the canvas
- Result: Canvas box moves, objects stay in place

## Additional Changes

### Sync Pan Value with Canvas Position

Added a useEffect to keep the pan slider value in sync with the current canvas position when switching axes.

```typescript
// Sync panValue with canvasPosition when axis changes
useEffect(() => {
  setPanValue(panAxis === 'x' ? canvasPosition.x : canvasPosition.y);
}, [panAxis, canvasPosition.x, canvasPosition.y]);
```

**Why This Is Needed**:
- When user switches from X to Y axis, slider should show current Y position
- When user switches from Y to X axis, slider should show current X position
- Without this, slider would show wrong value after axis change

## User Experience

### Before Fix

1. User draws on canvas
2. User adjusts pan slider
3. ❌ Drawing moves within canvas
4. ❌ Canvas box stays in same place
5. ❌ Confusing and unexpected behavior

### After Fix

1. User draws on canvas
2. User adjusts pan slider
3. ✅ Entire canvas box moves
4. ✅ Drawing stays in same position on canvas
5. ✅ Expected viewport panning behavior

## Technical Details

### Canvas Position State

```typescript
const [canvasPosition, setCanvasPosition] = useState({ x: 0, y: 0 });
```

This state controls the CSS transform applied to the canvas container:

```tsx
<div
  style={{
    transform: `translate(${canvasPosition.x}px, ${canvasPosition.y}px)`,
    // ... other styles
  }}
>
  <canvas ref={canvasRef} />
</div>
```

### Pan Control Flow

```
User moves slider
    ↓
handlePanChange(value)
    ↓
setCanvasPosition({ x: value } or { y: value })
    ↓
React re-renders with new transform
    ↓
Canvas container moves
    ↓
Objects maintain position relative to canvas
```

### Viewport Transform vs Container Position

**Viewport Transform** (viewportTransform):
- Fabric.js internal property
- Controls canvas content offset
- Used for zoom and pan within canvas
- Affects object coordinates
- ❌ Wrong for viewport panning

**Container Position** (canvasPosition):
- React state controlling CSS transform
- Moves entire canvas element
- Doesn't affect object coordinates
- Used for viewport navigation
- ✅ Correct for viewport panning

## Comparison

| Aspect | Before (Wrong) | After (Correct) |
|--------|----------------|-----------------|
| What moves | Canvas content | Canvas container |
| Objects | Move with pan | Stay in place |
| Canvas box | Stays fixed | Moves with pan |
| Behavior | Unexpected | Expected |
| User confusion | High | None |
| Matches expectations | ❌ No | ✅ Yes |

## Testing

### Test 1: Horizontal Pan
1. Draw object in center of canvas
2. Set pan axis to X
3. Move slider to -200
4. ✅ Canvas box moves left
5. ✅ Object stays in center of canvas
6. Move slider to 200
7. ✅ Canvas box moves right
8. ✅ Object still in center of canvas

### Test 2: Vertical Pan
1. Draw object in center of canvas
2. Set pan axis to Y
3. Move slider to -200
4. ✅ Canvas box moves up
5. ✅ Object stays in center of canvas
6. Move slider to 200
7. ✅ Canvas box moves down
8. ✅ Object still in center of canvas

### Test 3: Axis Switching
1. Set pan axis to X
2. Move slider to 100
3. ✅ Canvas moves right
4. Switch to Y axis
5. ✅ Slider shows current Y position (0)
6. Move slider to -100
7. ✅ Canvas moves up
8. Switch back to X axis
9. ✅ Slider shows 100 (preserved X position)

### Test 4: Combined with Dragging
1. Pan canvas to the right
2. Drag canvas with Space+drag
3. ✅ Both pan methods work together
4. ✅ Canvas position updates correctly
5. ✅ Pan slider reflects new position

## Benefits

✅ **Correct Behavior**: Canvas viewport pans as expected
✅ **Intuitive**: Matches user mental model
✅ **Professional**: Behaves like standard design tools
✅ **Predictable**: Objects stay on canvas, canvas moves in viewport
✅ **Consistent**: Works with other pan methods (Space+drag)
✅ **Clear**: Visual feedback matches user action

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Updated `handlePanChange` to modify `canvasPosition` instead of `viewportTransform`
  - Added `useEffect` to sync `panValue` with `canvasPosition` when axis changes

## Version

- v138: Fix pan control to move canvas viewport
- Pan now moves canvas container, not content
- Objects stay in place relative to canvas
- Correct viewport panning behavior ✅

## Related

- Canvas viewport management
- CSS transforms vs canvas transforms
- State synchronization
- User interface expectations
