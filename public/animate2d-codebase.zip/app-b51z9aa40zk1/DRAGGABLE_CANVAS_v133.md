# Draggable Canvas in Viewport - v133

## Overview

Made the entire canvas draggable within the viewport, allowing users to reposition the canvas by dragging it with Space+drag or middle mouse button.

## Features

### Canvas Dragging

The canvas can now be grabbed and moved around the viewport.

#### Drag Methods

1. **Space + Left Click Drag**
   - Hold Space key
   - Cursor changes to grab hand
   - Click and drag with left mouse button
   - Canvas moves with mouse
   - Release Space to stop

2. **Middle Mouse Button Drag**
   - Click and hold middle mouse button
   - Drag to move canvas
   - Release to stop

#### Visual Feedback

- **Space Pressed**: Cursor changes to `grab` 
- **Dragging**: Cursor changes to `grabbing`
- **Released**: Cursor returns to `default`

### How It Works

The canvas container position is tracked with state and applied via CSS transform:

```typescript
transform: `translate(${canvasPosition.x}px, ${canvasPosition.y}px) scale(${zoom / 100})`
```

This allows the canvas to:
- Move freely in X and Y directions
- Maintain zoom level while moving
- Provide smooth dragging experience
- Work independently of pan slider

## Implementation Details

### State Management

```typescript
const [canvasPosition, setCanvasPosition] = useState({ x: 0, y: 0 });
const [isDraggingCanvas, setIsDraggingCanvas] = useState(false);
const canvasDragStartRef = useRef<{ 
  x: number; 
  y: number; 
  canvasX: number; 
  canvasY: number 
} | null>(null);
```

### Event Handlers

```typescript
// Track Space key
const handleKeyDown = (e: KeyboardEvent) => {
  if (e.code === 'Space' && !isSpacePressed) {
    isSpacePressed = true;
    containerElement.style.cursor = 'grab';
  }
};

// Start dragging
const handleMouseDown = (e: MouseEvent) => {
  if (e.button === 1 || (isSpacePressed && e.button === 0)) {
    e.preventDefault();
    setIsDraggingCanvas(true);
    canvasDragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      canvasX: canvasPosition.x,
      canvasY: canvasPosition.y,
    };
    containerElement.style.cursor = 'grabbing';
  }
};

// Update position while dragging
const handleMouseMove = (e: MouseEvent) => {
  if (isDraggingCanvas && canvasDragStartRef.current) {
    const deltaX = e.clientX - canvasDragStartRef.current.x;
    const deltaY = e.clientY - canvasDragStartRef.current.y;
    
    setCanvasPosition({
      x: canvasDragStartRef.current.canvasX + deltaX,
      y: canvasDragStartRef.current.canvasY + deltaY,
    });
  }
};

// Stop dragging
const handleMouseUp = () => {
  if (isDraggingCanvas) {
    setIsDraggingCanvas(false);
    containerElement.style.cursor = isSpacePressed ? 'grab' : 'default';
  }
};
```

### Transform Application

```tsx
<div 
  className="relative flex items-center justify-center"
  style={{ 
    transform: `translate(${canvasPosition.x}px, ${canvasPosition.y}px) scale(${zoom / 100})`,
    transformOrigin: 'center center',
    transition: isDraggingCanvas ? 'none' : 'transform 0.2s ease-out'
  }}
>
  <canvas ref={canvasRef} />
</div>
```

### Key Features

- **No Transition While Dragging**: `transition: isDraggingCanvas ? 'none' : 'transform 0.2s ease-out'`
  - Prevents lag during drag
  - Smooth animation when released

- **Combined Transform**: `translate(...) scale(...)`
  - Position and zoom in one transform
  - Maintains zoom while moving

- **Transform Origin**: `center center`
  - Zoom from center
  - Consistent scaling behavior

## Usage

### Method 1: Space + Drag
1. Hold down Space key
2. Cursor changes to grab hand
3. Click and drag with left mouse
4. Canvas moves with cursor
5. Release Space when done

### Method 2: Middle Mouse
1. Click and hold middle mouse button
2. Drag to move canvas
3. Release to stop

### Combined with Zoom
1. Zoom in using zoom slider
2. Hold Space and drag to reposition
3. Canvas moves while maintaining zoom
4. Perfect for detail work

### Combined with Pan Slider
1. Use pan slider for precise positioning
2. Use Space+drag for quick repositioning
3. Both work independently
4. Choose method based on need

## Use Cases

### 1. Quick Repositioning
- Space+drag for fast canvas movement
- No need to use pan slider
- Intuitive hand tool behavior

### 2. Detail Work
- Zoom in on specific area
- Drag canvas to comfortable position
- Work on details
- Reposition as needed

### 3. Animation Workflow
- Position canvas for frame composition
- Drag to different areas quickly
- Maintain view while working
- Professional animation software feel

### 4. Large Canvas Navigation
- Move around large canvas easily
- Quick access to different areas
- No scrollbars needed
- Smooth navigation experience

## Benefits

✅ **Intuitive**: Space+drag is industry standard
✅ **Fast**: Quick repositioning without menus
✅ **Flexible**: Two methods (Space or middle mouse)
✅ **Smooth**: No lag or stuttering
✅ **Professional**: Matches design software UX
✅ **Non-Destructive**: Doesn't affect canvas content
✅ **Works with Zoom**: Maintains zoom level
✅ **Visual Feedback**: Cursor changes show state

## Comparison with Pan Slider

| Feature | Canvas Drag | Pan Slider |
|---------|-------------|------------|
| Speed | Fast | Precise |
| Method | Mouse drag | Slider control |
| Axes | Both X & Y | One at a time |
| Precision | Medium | High |
| Use Case | Quick move | Exact position |
| Feedback | Visual | Numeric |

Both methods complement each other:
- **Canvas Drag**: Quick, intuitive repositioning
- **Pan Slider**: Precise, controlled positioning

## Testing

### Test 1: Space + Drag
1. Hold Space key
2. ✅ Cursor changes to grab hand
3. Click and drag
4. ✅ Canvas moves smoothly
5. Release Space
6. ✅ Cursor returns to normal

### Test 2: Middle Mouse Drag
1. Click middle mouse button
2. Drag canvas
3. ✅ Canvas moves smoothly
4. Release button
5. ✅ Dragging stops

### Test 3: With Zoom
1. Zoom in to 150%
2. Space+drag to move
3. ✅ Canvas moves while zoomed
4. Zoom level maintained
5. ✅ Smooth movement

### Test 4: With Drawing Tools
1. Select brush tool
2. Draw something
3. Hold Space
4. ✅ Can drag canvas
5. Release Space
6. ✅ Can draw again

### Test 5: Combined Features
1. Use pan slider
2. Space+drag canvas
3. ✅ Both work independently
4. Use zoom slider
5. ✅ All features work together

## Technical Notes

### Event Listeners

- **Window Level**: `keydown`, `keyup`, `mousemove`, `mouseup`
  - Ensures events work even outside canvas
  - Prevents stuck states

- **Container Level**: `mousedown`
  - Starts drag on container
  - Allows dragging from anywhere

### State Management

- `canvasPosition`: Current X, Y position
- `isDraggingCanvas`: Dragging state flag
- `canvasDragStartRef`: Stores drag start position

### Performance

- No transition during drag for smooth movement
- Transform is GPU-accelerated
- Minimal re-renders with refs
- Efficient event handling

## Limitations

- Canvas can be dragged outside viewport (intentional)
- No snap-to-center feature (yet)
- Pan slider doesn't sync with drag position
- No bounds checking (canvas can go anywhere)

## Future Enhancements

- Reset canvas position button
- Snap to center shortcut
- Bounds limiting (keep canvas in viewport)
- Sync pan slider with drag position
- Canvas position indicator
- Keyboard shortcuts for nudging
- Grid snapping option

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Removed frame border rectangle
  - Added canvas position state
  - Added canvas dragging state
  - Added Space key tracking
  - Added mouse event handlers for dragging
  - Updated canvas container transform
  - Added cursor feedback

## Version

- v133: Made canvas draggable in viewport
- Space+drag or middle mouse to move canvas
- Smooth dragging with visual feedback
- Works with zoom and pan features
- All features working correctly ✅

## Related

- Canvas viewport management
- Transform-based positioning
- Mouse event handling
- Keyboard shortcuts
- Professional design tool UX
