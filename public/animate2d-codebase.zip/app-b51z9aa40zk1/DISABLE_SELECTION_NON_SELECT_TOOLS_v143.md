# Disable Object Selection for Non-Select Tools - v143

## Issue

Even after adding the dedicated Select tool in v142, objects were still selectable when using normal tools (shapes, text, image, etc.). This caused interference:

- User draws a rectangle
- Rectangle is created and automatically selected
- User tries to draw another rectangle
- Accidentally clicks on first rectangle
- First rectangle gets selected instead of starting new shape
- Confusing and disruptive workflow

## Root Cause

In v142, we disabled `canvas.selection` (the multi-select box) for non-select tools, but we didn't disable individual object selection. Objects still had `selectable: true` and `evented: true`, which meant:

- Clicking on objects would select them
- Objects could be moved/resized even when not using select tool
- Shape tools, text tool, etc. were interfered with by existing objects

## Solution

Make objects completely non-selectable when not using the Select tool:

1. **Tool Change**: Update all existing objects' `selectable` and `evented` properties based on current tool
2. **Object Creation**: Create new objects with `selectable` and `evented` set based on current tool
3. **Clear Selection**: Automatically deselect all objects when switching away from select tool
4. **Image Upload**: Switch to select tool after uploading image so user can move it

## Implementation

### 1. Update Existing Objects on Tool Change

```typescript
useEffect(() => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  const isDrawingTool = ['brush', 'eraser'].includes(drawingState.tool);
  const isSelectTool = drawingState.tool === 'select';

  // ... drawing mode logic ...

  // Make all objects selectable/non-selectable based on tool
  canvas.getObjects().forEach((obj: fabric.FabricObject) => {
    // Skip locked brush strokes
    if ((obj as any).__locked__) {
      return;
    }
    
    // Only make objects selectable when select tool is active
    obj.set({
      selectable: isSelectTool,
      evented: isSelectTool,
    });
  });
  
  // If switching away from select tool, clear any active selection
  if (!isSelectTool) {
    canvas.discardActiveObject();
  }
  
  canvas.renderAll();
}, [drawingState.tool, /* ... */]);
```

### 2. Create Shapes with Correct Selectable State

```typescript
const handleMouseUp = () => {
  const isSelectTool = drawingState.tool === 'select';
  
  // Handle shape drawing end
  if (shapeDrawingRef.current.isDrawing) {
    if (shapeDrawingRef.current.shape) {
      shapeDrawingRef.current.shape.set({ 
        selectable: isSelectTool, // ✅ Only selectable if select tool active
        evented: isSelectTool,    // ✅ Only evented if select tool active
        hasControls: true,
        hasBorders: true,
        // ... other properties ...
      });
      
      // Only select if select tool is active
      if (isSelectTool) {
        canvas.setActiveObject(shapeDrawingRef.current.shape);
        selectionCountRef.current = 1;
      }
      canvas.renderAll();
    }
  }
  // ... similar for lines ...
};
```

### 3. Create Text with Correct Selectable State

```typescript
const addText = (x: number, y: number) => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  const isSelectTool = drawingState.tool === 'select';

  const text = new fabric.IText('Text', {
    left: x,
    top: y,
    fontSize: 24,
    fontFamily: 'Arial',
    fill: drawingState.color,
    selectable: isSelectTool, // ✅ Only selectable if select tool active
    evented: isSelectTool,    // ✅ Only evented if select tool active
    // ... other properties ...
  });

  canvas.add(text);
  
  // Only select if select tool is active
  if (isSelectTool) {
    canvas.setActiveObject(text);
    selectionCountRef.current = 1;
    text.enterEditing(); // ✅ Enter editing mode
  }
  
  canvas.renderAll();
  autoSaveCanvas();
};
```

### 4. Upload Image and Switch to Select Tool

```typescript
const addImage = async (url: string) => {
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  try {
    const img = await fabric.FabricImage.fromURL(url, { crossOrigin: 'anonymous' });
    
    const isSelectTool = drawingState.tool === 'select';

    img.set({
      // ... positioning and scaling ...
      selectable: isSelectTool, // ✅ Only selectable if select tool active
      evented: isSelectTool,    // ✅ Only evented if select tool active
      // ... other properties ...
    });

    canvas.add(img);
    
    // Only select if select tool is active
    if (isSelectTool) {
      canvas.setActiveObject(img);
      selectionCountRef.current = 1;
    }
    
    canvas.renderAll();
    
    // ✅ Switch to select tool so user can move the image
    setTool('select');
    
    autoSaveCanvas();
  } catch (error) {
    console.error('[IMAGE] Error loading image:', error);
  }
};
```

## How It Works

### Object Selectability Matrix

| Tool | Existing Objects Selectable | New Objects Selectable | Auto-Select After Create |
|------|----------------------------|------------------------|--------------------------|
| **Select** | ✅ Yes | ✅ Yes | ✅ Yes |
| **Brush** | ❌ No | N/A (brush strokes locked) | ❌ No |
| **Eraser** | ❌ No | N/A (eraser removes) | ❌ No |
| **Rectangle** | ❌ No | ❌ No | ❌ No |
| **Circle** | ❌ No | ❌ No | ❌ No |
| **Triangle** | ❌ No | ❌ No | ❌ No |
| **Line** | ❌ No | ❌ No | ❌ No |
| **Text** | ❌ No | ❌ No | ❌ No |
| **Image** | ❌ No | ❌ No | ❌ No (but switches to select) |

### Workflow Examples

**Drawing Multiple Rectangles**:
```
1. User presses 'R' (rectangle tool)
2. User draws rectangle A
3. Rectangle A created (not selectable, not selected)
4. User draws rectangle B
5. Rectangle B created (not selectable, not selected)
6. User can draw freely without interference
7. User presses 'V' (select tool)
8. All rectangles become selectable
9. User can now select and move them
```

**Adding Text**:
```
1. User presses 'T' (text tool)
2. User clicks on canvas
3. Text created (not selectable if not in select mode)
4. If select tool active: text is selected and editing mode enabled
5. If other tool active: text is created but not selected
6. User presses 'V' to select and edit text later
```

**Uploading Image**:
```
1. User uploads image (any tool active)
2. Image is added to canvas
3. Tool automatically switches to select tool
4. Image becomes selectable
5. Image is selected
6. User can immediately move/resize image
```

## User Experience

### Before Fix (v142)

**Drawing Multiple Shapes**:
1. Select rectangle tool
2. Draw first rectangle
3. ❌ Rectangle is selectable
4. Try to draw second rectangle
5. ❌ Accidentally click on first rectangle
6. ❌ First rectangle gets selected
7. ❌ Can't draw second rectangle
8. ❌ Frustrating workflow

**Using Text Tool**:
1. Select text tool
2. Add text "Hello"
3. ❌ Text is selectable
4. Try to add another text
5. ❌ Accidentally click on "Hello"
6. ❌ "Hello" gets selected
7. ❌ Can't add new text
8. ❌ Confusing behavior

### After Fix (v143)

**Drawing Multiple Shapes**:
1. Select rectangle tool
2. Draw first rectangle
3. ✅ Rectangle is NOT selectable
4. Draw second rectangle
5. ✅ No interference from first rectangle
6. Draw third rectangle
7. ✅ Clean workflow
8. Press 'V' to select tool
9. ✅ All rectangles become selectable
10. ✅ Can now move/edit them

**Using Text Tool**:
1. Select text tool
2. Add text "Hello"
3. ✅ Text is NOT selectable
4. Add text "World"
5. ✅ No interference from "Hello"
6. ✅ Clean workflow
7. Press 'V' to select tool
8. ✅ All text becomes selectable
9. ✅ Can now select and edit

**Uploading Image**:
1. Upload image (any tool active)
2. ✅ Tool switches to select
3. ✅ Image is selectable
4. ✅ Image is selected
5. ✅ Can immediately move image
6. ✅ Intuitive workflow

## Benefits

✅ **Clean Workflow**: No interference when creating multiple objects
✅ **Predictable**: Objects only selectable in select mode
✅ **Professional**: Matches industry-standard design tools
✅ **Efficient**: Can create many objects quickly
✅ **Intuitive**: Clear separation between creation and manipulation
✅ **Image Upload**: Automatically switches to select tool for immediate manipulation

## Comparison

| Aspect | v142 (Before) | v143 (After) |
|--------|---------------|--------------|
| Draw multiple rectangles | ❌ Interference | ✅ Clean |
| Draw multiple circles | ❌ Interference | ✅ Clean |
| Add multiple text | ❌ Interference | ✅ Clean |
| Objects selectable in shape mode | ❌ Yes | ✅ No |
| Objects selectable in select mode | ✅ Yes | ✅ Yes |
| Image upload tool switch | ❌ Image tool | ✅ Select tool |
| Workflow efficiency | ❌ Low | ✅ High |

## Design Rationale

### Why Disable Selection for Non-Select Tools?

**Industry Standards**:
- **Figma**: Objects only selectable with select tool (V)
- **Sketch**: Objects only selectable with select tool (V)
- **Adobe XD**: Objects only selectable with select tool (V)
- **Illustrator**: Objects only selectable with selection tool (V)

**User Workflow**:
1. **Creation Phase**: User creates multiple objects quickly
   - No interference from existing objects
   - Focus on creating, not selecting
   
2. **Manipulation Phase**: User switches to select tool
   - All objects become selectable
   - Can move, resize, delete, etc.

**Clear Mental Model**:
- **Creation Tools**: Create new objects (rectangle, circle, text, etc.)
- **Selection Tool**: Manipulate existing objects
- No confusion about tool purpose

### Why Switch to Select Tool After Image Upload?

**User Intent**:
- User uploads image to add it to canvas
- Next logical action: position the image
- Requires select tool to move/resize

**Automatic Tool Switch**:
- Saves user from manually switching to select tool
- Image is immediately selectable and selected
- User can drag to position right away
- Matches user's expected workflow

## Testing

### Test 1: Draw Multiple Rectangles
1. Press 'R' (rectangle tool)
2. Draw rectangle A
3. ✅ Rectangle A not selectable
4. Draw rectangle B
5. ✅ No interference from A
6. Draw rectangle C
7. ✅ No interference from A or B
8. Press 'V' (select tool)
9. ✅ All rectangles become selectable

### Test 2: Draw Multiple Circles
1. Press 'C' (circle tool)
2. Draw 5 circles
3. ✅ No interference between circles
4. Press 'V' (select tool)
5. ✅ All circles become selectable

### Test 3: Add Multiple Text
1. Press 'T' (text tool)
2. Click to add text "A"
3. ✅ Text A not selectable
4. Click to add text "B"
5. ✅ No interference from A
6. Press 'V' (select tool)
7. ✅ Both texts become selectable

### Test 4: Upload Image
1. Have rectangle tool selected
2. Upload an image
3. ✅ Tool switches to select
4. ✅ Image is selectable
5. ✅ Image is selected
6. Drag image
7. ✅ Image moves

### Test 5: Switch Between Tools
1. Press 'R' (rectangle tool)
2. Draw rectangle
3. ✅ Rectangle not selectable
4. Press 'V' (select tool)
5. ✅ Rectangle becomes selectable
6. Click rectangle
7. ✅ Rectangle is selected
8. Press 'R' (rectangle tool)
9. ✅ Rectangle becomes non-selectable
10. ✅ Selection is cleared

### Test 6: Mixed Objects
1. Draw rectangle (R)
2. Draw circle (C)
3. Add text (T)
4. Upload image
5. ✅ Tool switches to select
6. ✅ All objects become selectable
7. Press 'R' (rectangle tool)
8. ✅ All objects become non-selectable
9. Draw another rectangle
10. ✅ No interference

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Updated drawing mode useEffect to set selectable/evented on all objects
  - Added auto-deselect when switching away from select tool
  - Updated handleMouseUp to create shapes/lines with correct selectable state
  - Updated addText to create text with correct selectable state
  - Updated addImage to create images with correct selectable state
  - Changed image upload to switch to select tool instead of image tool

## Version

- v143: Disable object selection for non-select tools
- Objects only selectable when select tool is active
- Clean workflow for creating multiple objects
- Image upload automatically switches to select tool
- Matches industry-standard design tool behavior ✅

## Related

- Object selection
- Tool behavior
- Workflow efficiency
- User experience
- Industry standards
- Image upload
