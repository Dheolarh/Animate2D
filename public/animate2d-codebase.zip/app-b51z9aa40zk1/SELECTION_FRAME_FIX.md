# Selection Frame Not Showing on First Draw - Fix

## Problem Description

**Symptom:** When drawing shapes (rectangle, circle, triangle, line) for the first time, the selection frame doesn't appear. However, after switching to a different shape tool and coming back, the shapes become selectable and any new shapes drawn also show selection frames correctly.

## Root Cause

The issue was that when making shapes selectable on mouse up, we were only setting the boolean flags (`selectable: true`, `evented: true`, etc.) but NOT the visual styling properties (`borderColor`, `cornerColor`, `cornerSize`, etc.).

### Why This Happened

1. **Prototype Settings:** The selection control styling was set on `fabric.Object.prototype` during canvas initialization
2. **Timing Issue:** When shapes were created with `selectable: false` during drawing, they didn't inherit the prototype settings
3. **Incomplete Update:** When we called `shape.set({ selectable: true })` on mouse up, it only updated the boolean flags, not the visual properties
4. **Why It Worked After Switching:** When you switched tools and came back, the canvas re-rendered and the prototype settings were applied to existing objects

## The Fix

### Before (Buggy Code)

```typescript
const handleMouseUp = () => {
  if (shapeDrawingRef.current.isDrawing) {
    if (shapeDrawingRef.current.shape) {
      // Only setting boolean flags - NO visual properties!
      shapeDrawingRef.current.shape.set({ 
        selectable: true,
        evented: true,
        hasControls: true,
        hasBorders: true,
      });
      canvas.setActiveObject(shapeDrawingRef.current.shape);
    }
    // ...
  }
};
```

### After (Fixed Code)

```typescript
const handleMouseUp = () => {
  if (shapeDrawingRef.current.isDrawing) {
    if (shapeDrawingRef.current.shape) {
      // CRITICAL: Set ALL selection properties explicitly
      shapeDrawingRef.current.shape.set({ 
        selectable: true,
        evented: true,
        hasControls: true,
        hasBorders: true,
        // Visual styling properties
        borderColor: 'rgba(0, 0, 0, 0.6)',
        cornerColor: 'rgba(0, 0, 0, 0.9)',
        cornerStyle: 'circle',
        cornerSize: 12,
        transparentCorners: false,
        borderScaleFactor: 2,
        padding: 8,
        borderDashArray: [5, 5],
      });
      canvas.setActiveObject(shapeDrawingRef.current.shape);
      canvas.renderAll(); // Force render to show selection
    }
    // ...
  }
};
```

## Key Changes

1. **Explicit Visual Properties:** Added all selection control styling properties when making shapes selectable
2. **Force Render:** Added `canvas.renderAll()` after setting active object to ensure selection frame is drawn immediately
3. **Consistency:** Applied the same fix to lines, shapes, text, and images

## Files Modified

1. **FabricDrawingCanvas.tsx**
   - Updated `handleMouseUp` for shapes
   - Updated `handleMouseUp` for lines
   - Updated `addText` function
   - Updated `addImage` function

2. **src/copiables/fabricHelpers.ts**
   - Updated `makeObjectSelectable` function
   - Updated `addText` function
   - Updated `addImage` function

## Selection Control Properties Explained

```typescript
{
  // Boolean flags
  selectable: true,          // Object can be selected
  evented: true,             // Object receives events
  hasControls: true,         // Show corner handles
  hasBorders: true,          // Show selection border
  
  // Visual styling
  borderColor: 'rgba(0, 0, 0, 0.6)',     // Selection border color (semi-transparent black)
  cornerColor: 'rgba(0, 0, 0, 0.9)',     // Corner handle color (darker black)
  cornerStyle: 'circle',                  // Corner handle shape (circle or rect)
  cornerSize: 12,                         // Size of corner handles in pixels
  transparentCorners: false,              // Solid corner handles (not transparent)
  borderScaleFactor: 2,                   // Border thickness multiplier
  padding: 8,                             // Padding around object for selection area
  borderDashArray: [5, 5],                // Dashed border pattern [dash, gap]
}
```

## Why Explicit Properties Are Necessary

### Fabric.js Object Creation Flow

1. **Object Created:** `new fabric.Rect({ selectable: false })`
   - Object is created with `selectable: false`
   - Prototype settings are NOT applied because object is not selectable

2. **Object Made Selectable:** `object.set({ selectable: true })`
   - Only updates the properties you specify
   - Does NOT automatically apply prototype settings
   - Visual properties remain undefined

3. **Solution:** Explicitly set ALL properties when making selectable
   - Ensures visual properties are set
   - Selection frame appears immediately
   - Consistent behavior across all objects

## Testing Checklist

- [x] Draw rectangle - selection frame appears immediately
- [x] Draw circle - selection frame appears immediately
- [x] Draw triangle - selection frame appears immediately
- [x] Draw line - selection frame appears immediately
- [x] Add text - selection frame appears immediately
- [x] Add image - selection frame appears immediately
- [x] Switch tools and come back - selection still works
- [x] Multiple shapes - all show selection frames
- [x] Selection controls are visible (borders, corners)
- [x] Selection controls are functional (resize, rotate, move)

## Best Practice

**Always explicitly set ALL object properties when changing object state.**

Don't rely on prototype settings to be automatically applied. When you change an object's state (like making it selectable), explicitly set all the properties you need.

```typescript
// ❌ BAD: Relying on prototype
object.set({ selectable: true });

// ✅ GOOD: Explicit properties
object.set({
  selectable: true,
  evented: true,
  hasControls: true,
  hasBorders: true,
  borderColor: 'rgba(0, 0, 0, 0.6)',
  cornerColor: 'rgba(0, 0, 0, 0.9)',
  cornerStyle: 'circle',
  cornerSize: 12,
  transparentCorners: false,
  borderScaleFactor: 2,
  padding: 8,
  borderDashArray: [5, 5],
});
```

## Related Issues

This fix also resolves:
- Selection frame not visible on first draw
- Inconsistent selection behavior between first and subsequent draws
- Selection controls appearing after tool switch but not before

## Performance Impact

**Negligible.** Setting explicit properties on mouse up is a one-time operation per shape and has no measurable performance impact.

## Version

- Fixed in: v104
- Related to: v102 (path locking fix), v103 (proper canvas system)
