# Pan Control Feature - v131

## Overview

Added a pan range control with axis selection above the zoom slider, allowing precise canvas viewport positioning along X or Y axis.

## Features

### Pan Range Slider
- Located above the zoom slider (bottom right)
- Range: -500 to +500 pixels
- Real-time viewport adjustment
- Shows current pan value

### Axis Selection Dropdown
- Choose between X axis or Y axis
- Compact dropdown with X/Y options
- Remembers selected axis

### How It Works

The pan control adjusts the Fabric.js viewport transform:
- **X Axis**: Moves canvas left/right (horizontal pan)
- **Y Axis**: Moves canvas up/down (vertical pan)

## UI Layout

```
┌─────────────────────┐
│ Pan: [X▼]           │  ← Axis selector
│ 0    ━━━━━━━━━━━━━  │  ← Pan slider
└─────────────────────┘
┌─────────────────────┐
│ 50%  ━━━━━━━━━━━━━  │  ← Zoom slider
└─────────────────────┘
```

## Usage

### Pan on X Axis
1. Select "X" from dropdown
2. Move slider left: canvas moves right (negative values)
3. Move slider right: canvas moves left (positive values)
4. Center (0): default position

### Pan on Y Axis
1. Select "Y" from dropdown
2. Move slider left: canvas moves down (negative values)
3. Move slider right: canvas moves up (positive values)
4. Center (0): default position

## Use Cases

### 1. Precise Positioning
- Center specific objects in viewport
- Align canvas to specific coordinates
- Fine-tune viewport after zooming

### 2. Animation Framing
- Position canvas for specific frame composition
- Maintain consistent viewport across frames
- Create camera movement effects

### 3. Detail Work
- Zoom in and pan to specific area
- Work on edges or corners
- Navigate large canvases systematically

## Implementation Details

### State Management

```typescript
const [panAxis, setPanAxis] = useState<'x' | 'y'>('x');
const [panValue, setPanValue] = useState(0);
```

### Pan Handler

```typescript
const handlePanChange = (value: number) => {
  setPanValue(value);
  const canvas = fabricCanvasRef.current;
  if (!canvas) return;

  const vpt = canvas.viewportTransform;
  if (vpt) {
    if (panAxis === 'x') {
      vpt[4] = value; // X translation
    } else {
      vpt[5] = value; // Y translation
    }
    canvas.requestRenderAll();
  }
};
```

### Viewport Transform Matrix

Fabric.js uses a 6-element transform matrix:
```
[a, b, c, d, e, f]
```

Where:
- `a, b, c, d`: Scale and rotation
- `e` (index 4): X translation (horizontal pan)
- `f` (index 5): Y translation (vertical pan)

## UI Components

### Pan Control Card
```tsx
<div className="absolute bottom-20 right-4 z-30 bg-card/95 backdrop-blur-sm border rounded-xl shadow-lg px-4 py-2 flex flex-col gap-2 min-w-[200px]">
  {/* Axis selector */}
  <div className="flex items-center gap-2">
    <span className="text-xs text-muted-foreground">Pan:</span>
    <Select value={panAxis} onValueChange={setPanAxis}>
      <SelectTrigger className="h-7 text-xs w-16">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="x">X</SelectItem>
        <SelectItem value="y">Y</SelectItem>
      </SelectContent>
    </Select>
  </div>
  
  {/* Pan slider */}
  <div className="flex items-center gap-3">
    <span className="text-xs text-muted-foreground">{panValue}</span>
    <input
      type="range"
      min="-500"
      max="500"
      value={panValue}
      onChange={(e) => handlePanChange(Number(e.target.value))}
      className="flex-1 accent-foreground"
    />
  </div>
</div>
```

## Styling

- **Position**: `bottom-20 right-4` (above zoom slider)
- **Background**: Card with backdrop blur
- **Border**: Rounded with shadow
- **Layout**: Vertical flex with 2px gap
- **Min Width**: 200px to match zoom slider

## Testing

### Test 1: X Axis Pan
1. Select "X" from dropdown
2. Move slider to -200
3. ✅ Canvas should move right
4. Move slider to +200
5. ✅ Canvas should move left
6. Return to 0
7. ✅ Canvas should center

### Test 2: Y Axis Pan
1. Select "Y" from dropdown
2. Move slider to -200
3. ✅ Canvas should move down
4. Move slider to +200
5. ✅ Canvas should move up
6. Return to 0
7. ✅ Canvas should center

### Test 3: Combined with Zoom
1. Zoom in to 150%
2. Pan on X axis
3. ✅ Should pan zoomed view
4. Switch to Y axis
5. Pan on Y axis
6. ✅ Should pan independently

### Test 4: Combined with Right-Click Pan
1. Use pan slider to position canvas
2. Right-click and drag to pan
3. ✅ Both should work together
4. Slider value doesn't update from drag
5. ✅ This is expected behavior

## Benefits

✅ **Precise Control**: Exact pixel positioning
✅ **Axis Independence**: Pan X and Y separately
✅ **Visual Feedback**: See pan value in real-time
✅ **Easy Reset**: Slider center returns to 0
✅ **Complements Zoom**: Works with zoom feature
✅ **Professional Tool**: Matches design software UX

## Limitations

- Pan slider doesn't update when using right-click drag pan
- This is intentional to avoid conflicts
- Slider represents manual pan offset only

## Future Enhancements

- Reset button to center both X and Y
- Keyboard shortcuts (Shift+Arrow for pan)
- Link pan values to show both X and Y simultaneously
- Pan presets (center, top-left, etc.)
- Sync slider with right-click pan position

## Files Modified

- `src/components/editor/canvas/FabricDrawingCanvas.tsx`
  - Added `panAxis` and `panValue` state
  - Added `handlePanChange` function
  - Imported Select components
  - Added pan control UI above zoom slider

## Version

- v131: Added pan range control with axis selection
- Positioned above zoom slider
- All features working correctly ✅

## Related

- Fabric.js viewport transform
- Canvas panning techniques
- UI/UX for design tools
- Viewport positioning
